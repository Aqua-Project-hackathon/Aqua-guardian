"use client"

import Link from "next/link"
import { Activity, AlertTriangle, ArrowRight } from "lucide-react"
import { useStore } from "@/lib/store"
import { HEALTH_COLORS, HEALTH_LABELS, summarize, type Health } from "@/lib/pipeline"
import { MapLegend } from "@/components/pipeline-map"

export default function PipelineStatusPage() {
  const { zones, getNetwork, totalAreaSqFt } = useStore()

  const perZone = zones.map((zone) => ({ zone, stats: summarize(getNetwork(zone)) }))
  const totals = perZone.reduce(
    (acc, { stats }) => {
      acc.bad += stats.bad
      acc.good += stats.good
      acc.better += stats.better
      acc.heavy += stats.heavy
      acc.total += stats.total
      return acc
    },
    { bad: 0, good: 0, better: 0, heavy: 0, total: 0 },
  )

  return (
    <div className="mx-auto w-full max-w-6xl p-6">
      <div className="mb-6 flex items-center gap-3">
        <span className="flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Activity className="size-6" aria-hidden="true" />
        </span>
        <div>
          <h1 className="text-3xl font-bold text-foreground">Pipe Line Status</h1>
          <p className="text-sm text-muted-foreground">
            Network health across {zones.length} zones · {totalAreaSqFt.toLocaleString()} sq ft
            monitored
          </p>
        </div>
      </div>

      {totals.heavy > 0 && (
        <div className="mb-6 flex items-center gap-3 rounded-xl border border-red-300 bg-red-50 p-4 text-red-800">
          <AlertTriangle className="size-5 shrink-0" aria-hidden="true" />
          <p className="text-sm font-medium">
            {totals.heavy} heavy-damage point{totals.heavy > 1 ? "s" : ""} across the network need
            urgent repair.
          </p>
        </div>
      )}

      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <TotalCard label="Junctions" value={totals.total} />
        <TotalCard label="Healthy" value={totals.better} health="better" />
        <TotalCard label="Aging" value={totals.good} health="good" />
        <TotalCard label="Damaged" value={totals.bad} health="bad" />
      </div>

      <div className="mb-6">
        <MapLegend />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {perZone.map(({ zone, stats }) => (
          <Link
            key={zone.id}
            href={`/zones/${zone.id}`}
            className="group flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary"
          >
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-foreground">{zone.name}</h2>
                <p className="text-sm text-muted-foreground">
                  {zone.areaSqFt.toLocaleString()} sq ft
                </p>
              </div>
              <span
                className="rounded-full px-3 py-1 text-xs font-semibold text-white"
                style={{ backgroundColor: HEALTH_COLORS[stats.overall] }}
              >
                {HEALTH_LABELS[stats.overall]}
              </span>
            </div>

            <HealthBar stats={stats} />

            <div className="flex items-center justify-between text-sm">
              <div className="flex gap-4">
                <LegendCount label="Healthy" value={stats.better} health="better" />
                <LegendCount label="Aging" value={stats.good} health="good" />
                <LegendCount label="Damaged" value={stats.bad} health="bad" />
              </div>
              {stats.heavy > 0 && (
                <span className="flex items-center gap-1 font-semibold text-red-600">
                  <AlertTriangle className="size-4" aria-hidden="true" />
                  {stats.heavy}
                </span>
              )}
            </div>

            <span className="inline-flex items-center gap-1 text-sm font-medium text-primary">
              Open zone map
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
            </span>
          </Link>
        ))}
      </div>
    </div>
  )
}

function HealthBar({ stats }: { stats: ReturnType<typeof summarize> }) {
  const total = Math.max(1, stats.total)
  const segments: { health: Health; value: number }[] = [
    { health: "better", value: stats.better },
    { health: "good", value: stats.good },
    { health: "bad", value: stats.bad },
  ]
  return (
    <div className="flex h-3 w-full overflow-hidden rounded-full bg-muted">
      {segments.map((s) => (
        <div
          key={s.health}
          style={{ width: `${(s.value / total) * 100}%`, backgroundColor: HEALTH_COLORS[s.health] }}
        />
      ))}
    </div>
  )
}

function TotalCard({ label, value, health }: { label: string; value: number; health?: Health }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-2">
        {health && (
          <span
            className="inline-block size-3 rounded-full"
            style={{ backgroundColor: HEALTH_COLORS[health] }}
          />
        )}
        <span className="text-sm text-muted-foreground">{label}</span>
      </div>
      <p className="mt-1 text-2xl font-bold text-foreground">{value}</p>
    </div>
  )
}

function LegendCount({ label, value, health }: { label: string; value: number; health: Health }) {
  return (
    <span className="flex items-center gap-1.5 text-muted-foreground">
      <span
        className="inline-block size-2.5 rounded-full"
        style={{ backgroundColor: HEALTH_COLORS[health] }}
      />
      {label} <span className="font-semibold text-foreground">{value}</span>
    </span>
  )
}
