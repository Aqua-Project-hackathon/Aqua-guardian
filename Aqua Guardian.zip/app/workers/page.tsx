"use client"

import Link from "next/link"
import { ArrowRight, Eye, MapPinned } from "lucide-react"
import { LoginGate } from "@/components/auth/login-gate"
import { useStore } from "@/lib/store"
import { HEALTH_COLORS, HEALTH_LABELS, summarize } from "@/lib/pipeline"

export default function WorkersPage() {
  return (
    <LoginGate role="worker" title="Workers Area" hint="Sign in to view zones and pipeline health.">
      <WorkerDashboard />
    </LoginGate>
  )
}

function WorkerDashboard() {
  const { zones, getNetwork, session, totalAreaSqFt } = useStore()
  const perZone = zones.map((zone) => ({ zone, stats: summarize(getNetwork(zone)) }))

  return (
    <div className="mx-auto w-full max-w-6xl p-6">
      <div className="mb-6 flex items-center gap-3">
        <span className="flex size-11 items-center justify-center rounded-xl bg-accent text-accent-foreground">
          <Eye className="size-6" aria-hidden="true" />
        </span>
        <div>
          <h1 className="text-3xl font-bold text-foreground">Welcome, {session?.username}</h1>
          <p className="text-sm text-muted-foreground">
            Read-only field view · {zones.length} zones · {totalAreaSqFt.toLocaleString()} sq ft
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {perZone.map(({ zone, stats }) => (
          <Link
            key={zone.id}
            href={`/zones/${zone.id}`}
            className="group flex flex-col gap-3 rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary"
          >
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 font-bold text-foreground">
                <MapPinned className="size-4 text-primary" aria-hidden="true" />
                {zone.name}
              </span>
              <span
                className="rounded-full px-2.5 py-1 text-xs font-semibold text-white"
                style={{ backgroundColor: HEALTH_COLORS[stats.overall] }}
              >
                {HEALTH_LABELS[stats.overall]}
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              {zone.areaSqFt.toLocaleString()} sq ft ·{" "}
              <span className="font-medium text-red-600">{stats.bad} damaged</span>
              {stats.heavy > 0 && (
                <span className="font-semibold text-red-600"> · {stats.heavy} heavy</span>
              )}
            </p>
            <span className="inline-flex items-center gap-1 text-sm font-medium text-primary">
              View map
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
            </span>
          </Link>
        ))}
      </div>

      <div className="mt-6">
        <Link
          href="/pipeline-status"
          className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
        >
          Full Pipe Line Status
          <ArrowRight className="size-4" aria-hidden="true" />
        </Link>
      </div>
    </div>
  )
}
