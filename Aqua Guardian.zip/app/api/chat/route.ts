import {
  convertToModelMessages,
  createUIMessageStream,
  createUIMessageStreamResponse,
  generateText,
  type UIMessage,
} from "ai"
import { answerLocally } from "@/lib/assistant-knowledge"

export const maxDuration = 30

const MODEL = "openai/gpt-4o-mini"

const INSTRUCTIONS = `You are Aqua Guardian's assistant, an expert on a water-pipeline leakage and loss detection system.

About the app:
- Aqua Guardian monitors municipal water pipeline networks split into zones (Zone A, Zone B, Zone C, and any zones an admin adds).
- Each zone renders a map with a root-like branching pipe network. Pipe and junction health is shown as three levels: "bad" (red, damaged/leaking), "good" (amber, aging), and "better" (green, healthy).
- The Pipe Line Status page aggregates health across every zone.
- When a pipe suffers HEAVY damage, the system raises a red alert banner with a buzzer to notify admins and workers so a repair crew can be dispatched.
- Admins can add other admins, add workers, and add new zones (with a pipeline area in sq ft). Workers have read-only access to zones and pipeline status.
- Logins are protected: 3 failed attempts locks that role out for 5 minutes.

Help users understand water leakage detection, how to read the maps and health levels, what to do about damaged/heavy-damage pipes, and how to navigate the app. Keep answers concise, practical, and friendly. If asked something unrelated to water systems or the app, gently steer back.`

function extractText(message: UIMessage | undefined): string {
  if (!message) return ""
  return message.parts
    .filter((p) => p.type === "text")
    .map((p) => (p as { text: string }).text)
    .join(" ")
    .trim()
}

/** Stream a plain string back to the client as UI message text chunks. */
function streamText_(text: string) {
  const id = crypto.randomUUID()
  const words = text.split(/(\s+)/) // keep whitespace tokens for natural spacing
  return createUIMessageStream({
    async execute({ writer }) {
      writer.write({ type: "text-start", id })
      for (const word of words) {
        writer.write({ type: "text-delta", id, delta: word })
        await new Promise((r) => setTimeout(r, 12))
      }
      writer.write({ type: "text-end", id })
    },
  })
}

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json()
  const lastUserText = extractText([...messages].reverse().find((m) => m.role === "user"))

  // Try the real model via AI Gateway first.
  try {
    const { text } = await generateText({
      model: MODEL,
      system: INSTRUCTIONS,
      messages: await convertToModelMessages(messages),
    })
    return createUIMessageStreamResponse({ stream: streamText_(text) })
  } catch (error) {
    // The AI Gateway is unavailable (e.g. no billing configured on the Vercel
    // team, network error). Fall back to the built-in knowledge base so the
    // assistant still answers instead of failing silently.
    console.log("[v0] AI Gateway unavailable, using local knowledge base:", (error as Error)?.message)
    return createUIMessageStreamResponse({ stream: streamText_(answerLocally(lastUserText)) })
  }
}
