"use client"

import { useState } from "react"
import Link from "next/link"
import {
  CheckCircle2,
  LayoutGrid,
  MapPinned,
  Plus,
  ShieldCheck,
  UserPlus,
  Users,
  X,
} from "lucide-react"
import { LoginGate } from "@/components/auth/login-gate"
import { useStore } from "@/lib/store"
import { HEALTH_COLORS, HEALTH_LABELS, summarize } from "@/lib/pipeline"

export default function AdminPage() {
  return (
    <LoginGate role="admin" title="Admin Area" hint="Sign in to manage zones, workers, and admins.">
      <AdminDashboard />
    </LoginGate>
  )
}

function AdminDashboard() {
  const { admins, workers, zones, session, totalAreaSqFt, getNetwork } = useStore()
  const [showAddAdmin, setShowAddAdmin] = useState(false)

  return (
    <div className="mx-auto w-full max-w-6xl p-6">
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <ShieldCheck className="size-6" aria-hidden="true" />
          </span>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
            <p className="text-sm text-muted-foreground">Signed in as {session?.username}</p>
          </div>
        </div>
        {/* Add Admin — top right corner */}
        <button
          type="button"
          onClick={() => setShowAddAdmin(true)}
          className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-md transition-colors hover:bg-primary/90"
        >
          <UserPlus className="size-4" aria-hidden="true" />
          Add Admin
        </button>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <SummaryCard icon={LayoutGrid} label="Zones" value={zones.length} />
        <SummaryCard icon={MapPinned} label="Sq ft" value={totalAreaSqFt.toLocaleString()} />
        <SummaryCard icon={ShieldCheck} label="Admins" value={admins.length} />
        <SummaryCard icon={Users} label="Workers" value={workers.length} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <AddZoneCard />
        <AddWorkerCard />
      </div>

      <section className="mt-6">
        <h2 className="mb-3 text-lg font-bold text-foreground">Zones &amp; pipeline health</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {zones.map((zone) => {
            const stats = summarize(getNetwork(zone))
            return (
              <Link
                key={zone.id}
                href={`/zones/${zone.id}`}
                className="flex flex-col gap-2 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-foreground">{zone.name}</span>
                  <span
                    className="rounded-full px-2.5 py-0.5 text-xs font-semibold text-white"
                    style={{ backgroundColor: HEALTH_COLORS[stats.overall] }}
                  >
                    {HEALTH_LABELS[stats.overall]}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {zone.areaSqFt.toLocaleString()} sq ft · {stats.bad} damaged
                  {stats.heavy > 0 && (
                    <span className="font-semibold text-red-600"> · {stats.heavy} heavy</span>
                  )}
                </p>
              </Link>
            )
          })}
        </div>
      </section>

      <section className="mt-6 grid gap-6 lg:grid-cols-2">
        <RosterCard title="Admins" icon={ShieldCheck} names={admins.map((a) => a.username)} />
        <RosterCard title="Workers" icon={Users} names={workers.map((w) => w.username)} />
      </section>

      {showAddAdmin && <AddAdminModal onClose={() => setShowAddAdmin(false)} />}
    </div>
  )
}

function SummaryCard({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof LayoutGrid
  label: string
  value: string | number
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-2 text-muted-foreground">
        <Icon className="size-4" aria-hidden="true" />
        <span className="text-sm">{label}</span>
      </div>
      <p className="mt-1 text-2xl font-bold text-foreground">{value}</p>
    </div>
  )
}

function Field({
  id,
  label,
  ...props
}: { id: string; label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-medium">
        {label}
      </label>
      <input
        id={id}
        className="rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none ring-ring/50 focus-visible:ring-2"
        {...props}
      />
    </div>
  )
}

function Feedback({ ok, message }: { ok: boolean; message: string }) {
  return (
    <p
      className={
        ok
          ? "flex items-center gap-1.5 text-sm text-emerald-600"
          : "text-sm text-destructive"
      }
    >
      {ok && <CheckCircle2 className="size-4" aria-hidden="true" />}
      {message}
    </p>
  )
}

function AddZoneCard() {
  const { addZone } = useStore()
  const [name, setName] = useState("")
  const [area, setArea] = useState("")
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const result = addZone(name, Number(area))
    if (result.ok) {
      setFeedback({ ok: true, message: `Zone "${name.trim()}" added with a generated pipeline map.` })
      setName("")
      setArea("")
    } else {
      setFeedback({ ok: false, message: result.error ?? "Could not add zone." })
    }
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="mb-4 flex items-center gap-2">
        <MapPinned className="size-5 text-primary" aria-hidden="true" />
        <h2 className="text-lg font-bold text-foreground">Add Zone</h2>
      </div>
      <form onSubmit={submit} className="flex flex-col gap-4">
        <Field
          id="zone-name"
          label="Zone name"
          placeholder="e.g. Zone D — North District"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <Field
          id="zone-area"
          label="Pipeline area (sq ft)"
          type="number"
          min={1}
          placeholder="e.g. 10000"
          value={area}
          onChange={(e) => setArea(e.target.value)}
          required
        />
        {feedback && <Feedback ok={feedback.ok} message={feedback.message} />}
        <button
          type="submit"
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
        >
          <Plus className="size-4" aria-hidden="true" />
          Create zone
        </button>
      </form>
    </div>
  )
}

function AddWorkerCard() {
  const { addWorker } = useStore()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const result = addWorker(username, password)
    if (result.ok) {
      setFeedback({ ok: true, message: `Worker "${username.trim()}" can now sign in.` })
      setUsername("")
      setPassword("")
    } else {
      setFeedback({ ok: false, message: result.error ?? "Could not add worker." })
    }
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="mb-4 flex items-center gap-2">
        <Users className="size-5 text-primary" aria-hidden="true" />
        <h2 className="text-lg font-bold text-foreground">Add Worker</h2>
      </div>
      <form onSubmit={submit} className="flex flex-col gap-4">
        <Field
          id="worker-username"
          label="Username"
          placeholder="e.g. field.tech.02"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
        <Field
          id="worker-password"
          label="Password"
          type="password"
          placeholder="Set a password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        {feedback && <Feedback ok={feedback.ok} message={feedback.message} />}
        <button
          type="submit"
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
        >
          <UserPlus className="size-4" aria-hidden="true" />
          Create worker
        </button>
      </form>
    </div>
  )
}

function RosterCard({
  title,
  icon: Icon,
  names,
}: {
  title: string
  icon: typeof Users
  names: string[]
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="mb-3 flex items-center gap-2">
        <Icon className="size-5 text-primary" aria-hidden="true" />
        <h2 className="text-lg font-bold text-foreground">
          {title} <span className="text-muted-foreground">({names.length})</span>
        </h2>
      </div>
      <ul className="flex flex-wrap gap-2">
        {names.map((n) => (
          <li
            key={n}
            className="rounded-full border border-border bg-muted px-3 py-1 text-sm text-foreground"
          >
            {n}
          </li>
        ))}
      </ul>
    </div>
  )
}

function AddAdminModal({ onClose }: { onClose: () => void }) {
  const { addAdmin } = useStore()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const result = addAdmin(username, password)
    if (result.ok) {
      setFeedback({ ok: true, message: `Admin "${username.trim()}" created.` })
      setUsername("")
      setPassword("")
    } else {
      setFeedback({ ok: false, message: result.error ?? "Could not add admin." })
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="add-admin-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 id="add-admin-title" className="flex items-center gap-2 text-lg font-bold">
            <UserPlus className="size-5 text-primary" aria-hidden="true" />
            Add Admin
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="flex size-8 items-center justify-center rounded-md hover:bg-muted"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        </div>
        <form onSubmit={submit} className="flex flex-col gap-4">
          <Field
            id="admin-new-username"
            label="Username"
            placeholder="e.g. supervisor.jane"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <Field
            id="admin-new-password"
            label="Password"
            type="password"
            placeholder="Set a password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {feedback && <Feedback ok={feedback.ok} message={feedback.message} />}
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-border px-4 py-2 text-sm font-medium hover:bg-muted"
            >
              Done
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
            >
              <Plus className="size-4" aria-hidden="true" />
              Create admin
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
