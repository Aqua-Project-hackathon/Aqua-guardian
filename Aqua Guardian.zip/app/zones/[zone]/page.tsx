"use client"

import { use } from "react"
import Link from "next/link"
import { AlertTriangle, ArrowLeft, Ruler } from "lucide-react"
import { useStore } from "@/lib/store"
import { HEALTH_COLORS, HEALTH_LABELS, summarize } from "@/lib/pipeline"
import { MapLegend, PipelineMap } from "@/components/pipeline-map"

export default function ZonePage({ params }: { params: Promise<{ zone: string }> }) {
  const { zone: zoneId } = use(params)
  const { zones, getNetwork } = useStore()
  const zone = zones.find((z) => z.id === zoneId)

  if (!zone) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 p-6 text-center">
        <p className="text-lg font-semibold">Zone not found</p>
        <Link href="/pipeline-status" className="text-primary underline">
          Back to Pipe Line Status
        </Link>
      </div>
    )
  }

  const network = getNetwork(zone)
  const stats = summarize(network)

  return (
    <div className="mx-auto w-full max-w-6xl p-6">
      <Link
        href="/pipeline-status"
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" aria-hidden="true" />
        All zones
      </Link>

      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">{zone.name}</h1>
          <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
            <Ruler className="size-4" aria-hidden="true" />
            {zone.areaSqFt.toLocaleString()} sq ft of pipeline monitored
          </p>
        </div>
        <span
          className="rounded-full px-4 py-1.5 text-sm font-semibold text-white"
          style={{ backgroundColor: HEALTH_COLORS[stats.overall] }}
        >
          Overall: {HEALTH_LABELS[stats.overall]}
        </span>
      </div>

      {stats.heavy > 0 && (
        <div className="mb-6 flex items-center gap-3 rounded-xl border border-red-300 bg-red-50 p-4 text-red-800">
          <AlertTriangle className="size-5 shrink-0" aria-hidden="true" />
          <p className="text-sm font-medium">
            {stats.heavy} heavy-damage point{stats.heavy > 1 ? "s" : ""} detected in this zone.
            Immediate repair required to stop water loss.
          </p>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[1fr_260px]">
        <div className="flex flex-col gap-4">
          <PipelineMap network={network} label={zone.name} />
          <MapLegend />
        </div>

        <div className="flex flex-col gap-3">
          <StatCard label="Junctions" value={stats.total} tone="neutral" />
          <StatCard label="Healthy (better)" value={stats.better} tone="better" />
          <StatCard label="Aging (good)" value={stats.good} tone="good" />
          <StatCard label="Damaged (bad)" value={stats.bad} tone="bad" />
          <StatCard label="Heavy damage" value={stats.heavy} tone="bad" />
        </div>
      </div>
    </div>
  )
}

function StatCard({
  label,
  value,
  tone,
}: {
  label: string
  value: number
  tone: "neutral" | "bad" | "good" | "better"
}) {
  const color =
    tone === "neutral" ? undefined : HEALTH_COLORS[tone as "bad" | "good" | "better"]
  return (
    <div className="flex items-center justify-between rounded-xl border border-border bg-card p-4">
      <span className="flex items-center gap-2 text-sm text-muted-foreground">
        {color && (
          <span className="inline-block size-3 rounded-full" style={{ backgroundColor: color }} />
        )}
        {label}
      </span>
      <span className="text-xl font-bold text-foreground">{value}</span>
    </div>
  )
}
