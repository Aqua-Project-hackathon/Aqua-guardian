"use client"

import Link from "next/link"
import { ArrowRight, Droplets, MapPinned, ShieldCheck, Users } from "lucide-react"
import { useStore } from "@/lib/store"

export default function HomePage() {
  const { zones, totalZones, totalAreaSqFt } = useStore()

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 py-16">
      {/* ambient water backdrop */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-gradient-to-b from-sky-50 via-background to-cyan-50"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 left-1/2 size-[36rem] -translate-x-1/2 rounded-full bg-primary/10 blur-3xl"
      />

      <div className="relative flex max-w-3xl flex-col items-center text-center">
        <span className="mb-6 flex size-20 items-center justify-center rounded-3xl bg-primary text-primary-foreground shadow-lg shadow-primary/30">
          <Droplets className="size-11" aria-hidden="true" />
        </span>
        <h1 className="text-balance text-5xl font-extrabold tracking-tight text-foreground sm:text-6xl md:text-7xl">
          AQUA GUARDIAN
        </h1>
        <p className="mt-5 max-w-xl text-pretty text-lg text-muted-foreground">
          Real-time water leakage and loss detection across your pipeline network. Monitor every
          zone, spot damaged pipes early, and dispatch crews before losses grow.
        </p>

        <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/pipeline-status"
            className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-md transition-colors hover:bg-primary/90"
          >
            View Pipe Line Status
            <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
          <Link
            href="/admin"
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-accent"
          >
            <ShieldCheck className="size-4" aria-hidden="true" />
            Admin Area
          </Link>
          <Link
            href="/workers"
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-accent"
          >
            <Users className="size-4" aria-hidden="true" />
            Workers Area
          </Link>
        </div>

        <div className="mt-12 grid w-full grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="rounded-2xl border border-border bg-card/80 p-5 backdrop-blur">
            <p className="text-3xl font-bold text-primary">{totalZones}</p>
            <p className="mt-1 text-sm text-muted-foreground">Monitored zones</p>
          </div>
          <div className="rounded-2xl border border-border bg-card/80 p-5 backdrop-blur">
            <p className="text-3xl font-bold text-primary">{totalAreaSqFt.toLocaleString()}</p>
            <p className="mt-1 text-sm text-muted-foreground">Sq ft of pipeline</p>
          </div>
          <div className="rounded-2xl border border-border bg-card/80 p-5 backdrop-blur">
            <p className="text-3xl font-bold text-primary">24/7</p>
            <p className="mt-1 text-sm text-muted-foreground">Leak surveillance</p>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
          {zones.map((zone) => (
            <Link
              key={zone.id}
              href={`/zones/${zone.id}`}
              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-primary hover:text-primary"
            >
              <MapPinned className="size-4" aria-hidden="true" />
              {zone.name}
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
