import {
  HEALTH_COLORS,
  HEALTH_LABELS,
  MAP_HEIGHT,
  MAP_WIDTH,
  type PipeNetwork,
} from "@/lib/pipeline"

function MapBackground() {
  return (
    <g aria-hidden="true">
      <rect x="0" y="0" width={MAP_WIDTH} height={MAP_HEIGHT} fill="#e9efe6" />
      {/* parks / green blocks */}
      <rect x="40" y="60" width="150" height="120" rx="10" fill="#d6e7c6" />
      <rect x="600" y="330" width="170" height="150" rx="12" fill="#d6e7c6" />
      {/* water body */}
      <path
        d="M0 430 Q 120 400 240 440 T 520 440 Q 640 460 800 420 L 800 540 L 0 540 Z"
        fill="#bcd9ef"
      />
      <path
        d="M0 450 Q 120 425 240 460 T 520 460 Q 640 478 800 442"
        fill="none"
        stroke="#a7cbe8"
        strokeWidth="3"
      />
      {/* roads */}
      <g stroke="#ffffff" strokeWidth="14" strokeLinecap="round" opacity="0.9">
        <line x1="0" y1="130" x2="800" y2="150" />
        <line x1="0" y1="300" x2="800" y2="285" />
        <line x1="230" y1="0" x2="250" y2="540" />
        <line x1="540" y1="0" x2="520" y2="540" />
      </g>
      <g stroke="#e4e7de" strokeWidth="16" strokeLinecap="round" opacity="0.5">
        <line x1="0" y1="130" x2="800" y2="150" />
        <line x1="0" y1="300" x2="800" y2="285" />
        <line x1="230" y1="0" x2="250" y2="540" />
        <line x1="540" y1="0" x2="520" y2="540" />
      </g>
      {/* subtle grid */}
      <g stroke="#000000" strokeWidth="0.5" opacity="0.04">
        {Array.from({ length: 16 }).map((_, i) => (
          <line key={`v${i}`} x1={i * 50} y1={0} x2={i * 50} y2={MAP_HEIGHT} />
        ))}
        {Array.from({ length: 11 }).map((_, i) => (
          <line key={`h${i}`} x1={0} y1={i * 50} x2={MAP_WIDTH} y2={i * 50} />
        ))}
      </g>
    </g>
  )
}

export function PipelineMap({
  network,
  label,
  className,
}: {
  network: PipeNetwork
  label?: string
  className?: string
}) {
  const nodeById = new Map(network.nodes.map((n) => [n.id, n]))

  return (
    <div className={className}>
      <svg
        viewBox={`0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`}
        className="h-auto w-full rounded-xl border border-border shadow-sm"
        role="img"
        aria-label={
          label
            ? `${label} pipeline network map`
            : "Pipeline network map resembling branching roots"
        }
      >
        <MapBackground />

        {/* pipe casing (outer dark stroke for a pipe look) */}
        <g strokeLinecap="round" fill="none">
          {network.edges.map((edge) => {
            const a = nodeById.get(edge.from)
            const b = nodeById.get(edge.to)
            if (!a || !b) return null
            return (
              <line
                key={`c-${edge.id}`}
                x1={a.x}
                y1={a.y}
                x2={b.x}
                y2={b.y}
                stroke="#1f2937"
                strokeOpacity="0.25"
                strokeWidth={edge.width + 3}
              />
            )
          })}
        </g>

        {/* colored pipes by health */}
        <g strokeLinecap="round" fill="none">
          {network.edges.map((edge) => {
            const a = nodeById.get(edge.from)
            const b = nodeById.get(edge.to)
            if (!a || !b) return null
            return (
              <line
                key={edge.id}
                x1={a.x}
                y1={a.y}
                x2={b.x}
                y2={b.y}
                stroke={HEALTH_COLORS[edge.status]}
                strokeWidth={edge.width}
              >
                <title>{`Pipe ${a.id} → ${b.id}: ${HEALTH_LABELS[edge.status]}`}</title>
              </line>
            )
          })}
        </g>

        {/* damage markers on bad pipes */}
        <g>
          {network.edges
            .filter((e) => e.status === "bad")
            .map((edge) => {
              const a = nodeById.get(edge.from)
              const b = nodeById.get(edge.to)
              if (!a || !b) return null
              const mx = (a.x + b.x) / 2
              const my = (a.y + b.y) / 2
              return (
                <g key={`d-${edge.id}`} transform={`translate(${mx}, ${my})`}>
                  <circle r="7" fill="#fff" stroke="#ef4444" strokeWidth="2" />
                  <path
                    d="M -3 -3 L 3 3 M 3 -3 L -3 3"
                    stroke="#ef4444"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </g>
              )
            })}
        </g>

        {/* nodes / junctions */}
        <g>
          {network.nodes.map((node) => {
            const r = Math.max(3.5, 8 - node.depth * 1.1)
            const color = HEALTH_COLORS[node.status]
            return (
              <g key={node.id}>
                {node.heavy && (
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={r + 8}
                    fill="#ef4444"
                    style={{
                      transformOrigin: `${node.x}px ${node.y}px`,
                      animation: "aqua-pulse 1s ease-in-out infinite",
                    }}
                  />
                )}
                <circle
                  cx={node.x}
                  cy={node.y}
                  r={r}
                  fill={node.depth === 0 ? "#1e3a8a" : color}
                  stroke="#ffffff"
                  strokeWidth="1.5"
                >
                  <title>
                    {node.depth === 0
                      ? "Main supply junction"
                      : `Junction ${node.id}: ${HEALTH_LABELS[node.status]}${
                          node.heavy ? " — HEAVY DAMAGE" : ""
                        }`}
                  </title>
                </circle>
              </g>
            )
          })}
        </g>

        {label && (
          <g>
            <rect x="16" y="16" rx="6" width={label.length * 9 + 28} height="30" fill="#ffffff" opacity="0.9" />
            <text x="30" y="36" fontSize="16" fontWeight="700" fill="#1a3a5c">
              {label}
            </text>
          </g>
        )}
      </svg>
    </div>
  )
}

export function MapLegend() {
  return (
    <div className="flex flex-wrap items-center gap-4 text-sm">
      {(["better", "good", "bad"] as const).map((h) => (
        <span key={h} className="flex items-center gap-2">
          <span
            className="inline-block h-3 w-6 rounded-full"
            style={{ backgroundColor: HEALTH_COLORS[h] }}
          />
          {HEALTH_LABELS[h]}
        </span>
      ))}
      <span className="flex items-center gap-2">
        <span className="inline-flex size-4 items-center justify-center rounded-full border-2 border-red-500 text-[10px] text-red-500">
          ✕
        </span>
        Leak / damage point
      </span>
    </div>
  )
}
