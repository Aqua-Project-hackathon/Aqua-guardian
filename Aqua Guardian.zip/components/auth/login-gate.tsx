"use client"

import { useEffect, useRef, useState, type ReactNode } from "react"
import { AlertTriangle, Loader2, Lock, ShieldCheck, Users } from "lucide-react"
import { MAX_ATTEMPTS, useStore, type Role } from "@/lib/store"
import { cn } from "@/lib/utils"

function useCountdown(target: number) {
  const [remaining, setRemaining] = useState(() => Math.max(0, target - Date.now()))
  useEffect(() => {
    if (target <= Date.now()) {
      setRemaining(0)
      return
    }
    const id = setInterval(() => {
      const left = Math.max(0, target - Date.now())
      setRemaining(left)
      if (left <= 0) clearInterval(id)
    }, 1000)
    return () => clearInterval(id)
  }, [target])
  return remaining
}

function formatMs(ms: number) {
  const total = Math.ceil(ms / 1000)
  const m = Math.floor(total / 60)
  const s = total % 60
  return `${m}:${s.toString().padStart(2, "0")}`
}

export function LoginGate({
  role,
  title,
  hint,
  children,
}: {
  role: Role
  title: string
  hint: string
  children: ReactNode
}) {
  const { session, login, locks, hydrated } = useStore()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [attemptsLeft, setAttemptsLeft] = useState<number | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)

  const lockedUntil = locks[role].lockedUntil
  const remaining = useCountdown(lockedUntil)
  const isLocked = remaining > 0

  const Icon = role === "admin" ? ShieldCheck : Users

  if (session?.role === role) {
    return <>{children}</>
  }

  // A worker signed in should not see the admin area and vice versa.
  const wrongRole = session && session.role !== role

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (isLocked) return
    setSubmitting(true)
    const result = login(role, username, password)
    setSubmitting(false)
    if (result.ok) {
      setError(null)
      setAttemptsLeft(null)
      setPassword("")
      return
    }
    if (result.error === "locked") {
      setError("Too many failed attempts. Access temporarily blocked.")
      setAttemptsLeft(0)
    } else {
      setError("Incorrect username or password.")
      setAttemptsLeft(result.attemptsLeft ?? null)
    }
    setPassword("")
  }

  return (
    <div className="flex min-h-[calc(100vh-0px)] items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="rounded-2xl border border-border bg-card p-8 shadow-lg">
          <div className="mb-6 flex flex-col items-center text-center">
            <span
              className={cn(
                "mb-3 flex size-14 items-center justify-center rounded-full",
                role === "admin"
                  ? "bg-primary/10 text-primary"
                  : "bg-accent text-accent-foreground",
              )}
            >
              <Icon className="size-7" aria-hidden="true" />
            </span>
            <h1 className="text-2xl font-bold text-foreground">{title}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{hint}</p>
          </div>

          {wrongRole && (
            <div className="mb-4 flex items-start gap-2 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
              <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
              <span>
                You are signed in as a {session?.role}. Sign in with {role} credentials to
                continue.
              </span>
            </div>
          )}

          {isLocked ? (
            <div className="flex flex-col items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/5 p-6 text-center">
              <Lock className="size-8 text-destructive" aria-hidden="true" />
              <p className="font-semibold text-destructive">Access blocked</p>
              <p className="text-sm text-muted-foreground">
                Too many failed attempts. Try again in
              </p>
              <p className="text-3xl font-bold tabular-nums text-destructive">
                {formatMs(remaining)}
              </p>
            </div>
          ) : (
            <form ref={formRef} onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1.5">
                <label htmlFor={`${role}-username`} className="text-sm font-medium">
                  Username
                </label>
                <input
                  id={`${role}-username`}
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none ring-ring/50 focus-visible:ring-2"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <label htmlFor={`${role}-password`} className="text-sm font-medium">
                  Password
                </label>
                <input
                  id={`${role}-password`}
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none ring-ring/50 focus-visible:ring-2"
                />
              </div>

              {error && (
                <div className="flex items-center justify-between gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                  <span>{error}</span>
                  {attemptsLeft !== null && attemptsLeft > 0 && (
                    <span className="shrink-0 font-medium">
                      {attemptsLeft} of {MAX_ATTEMPTS} left
                    </span>
                  )}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting || !hydrated}
                className="flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
              >
                {submitting && <Loader2 className="size-4 animate-spin" aria-hidden="true" />}
                Sign in
              </button>

              <p className="rounded-lg bg-muted p-3 text-center text-xs text-muted-foreground">
                Demo {role} login —{" "}
                <span className="font-medium text-foreground">
                  {role === "admin" ? "admin / admin123" : "worker / worker123"}
                </span>
                . {role === "worker" ? "New workers are created by an admin." : ""}
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
