"use client"

import { useEffect, useRef, useState } from "react"
import Link from "next/link"
import { AlertTriangle, BellOff, BellRing, X } from "lucide-react"
import { useStore } from "@/lib/store"

export function AlertSystem() {
  const { session, getHeavyDamage, hydrated } = useStore()
  const [muted, setMuted] = useState(false)
  const [dismissed, setDismissed] = useState(false)
  const audioCtxRef = useRef<AudioContext | null>(null)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const heavy = hydrated ? getHeavyDamage() : []
  // Alert only surfaces to authenticated admins and workers.
  const active = Boolean(session) && heavy.length > 0 && !dismissed

  useEffect(() => {
    // Reset dismissal whenever the number of heavy alerts changes.
    setDismissed(false)
  }, [heavy.length])

  useEffect(() => {
    function stop() {
      if (timerRef.current) {
        clearInterval(timerRef.current)
        timerRef.current = null
      }
    }

    if (!active || muted) {
      stop()
      return
    }

    function beep() {
      try {
        const Ctx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
        if (!Ctx) return
        if (!audioCtxRef.current) audioCtxRef.current = new Ctx()
        const ctx = audioCtxRef.current
        if (ctx.state === "suspended") void ctx.resume()
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.type = "square"
        osc.frequency.value = 880
        gain.gain.setValueAtTime(0.0001, ctx.currentTime)
        gain.gain.exponentialRampToValueAtTime(0.15, ctx.currentTime + 0.02)
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35)
        osc.connect(gain)
        gain.connect(ctx.destination)
        osc.start()
        osc.stop(ctx.currentTime + 0.36)
      } catch {
        // Autoplay may be blocked until the first user gesture; the banner still shows.
      }
    }

    beep()
    timerRef.current = setInterval(beep, 1400)
    return stop
  }, [active, muted])

  if (!active) return null

  const first = heavy[0]
  const more = heavy.length - 1

  return (
    <div
      role="alert"
      aria-live="assertive"
      className="sticky top-0 z-30 flex flex-wrap items-center gap-3 border-b border-red-700 bg-red-600 px-4 py-3 text-white shadow-md"
    >
      <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-white/20">
        <AlertTriangle className="size-5 animate-pulse" aria-hidden="true" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-bold uppercase tracking-wide">Heavy pipe damage detected</p>
        <p className="text-sm text-white/90">
          Critical leakage in{" "}
          <Link href={`/zones/${first.zone.id}`} className="font-semibold underline">
            {first.zone.name}
          </Link>
          {more > 0 ? ` and ${more} more location${more > 1 ? "s" : ""}` : ""}. Dispatch a repair
          crew immediately.
        </p>
      </div>
      <div className="flex shrink-0 items-center gap-2">
        <button
          type="button"
          onClick={() => setMuted((m) => !m)}
          className="flex items-center gap-1.5 rounded-md bg-white/15 px-3 py-1.5 text-xs font-medium hover:bg-white/25"
        >
          {muted ? (
            <>
              <BellOff className="size-4" aria-hidden="true" /> Buzzer off
            </>
          ) : (
            <>
              <BellRing className="size-4 animate-pulse" aria-hidden="true" /> Silence buzzer
            </>
          )}
        </button>
        <button
          type="button"
          onClick={() => setDismissed(true)}
          aria-label="Dismiss alert"
          className="flex size-8 items-center justify-center rounded-md bg-white/15 hover:bg-white/25"
        >
          <X className="size-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  )
}
