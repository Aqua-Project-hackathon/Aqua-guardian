"use client"

import type { ReactNode } from "react"
import { Sidebar } from "./sidebar"
import { AlertSystem } from "@/components/alert-system"
import { Chatbot } from "@/components/chatbot"

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <Sidebar />
      <div className="relative flex min-w-0 flex-1 flex-col">
        <AlertSystem />
        <main className="flex-1">{children}</main>
      </div>
      <Chatbot />
    </div>
  )
}
