"use client"

import type { ComponentType, ReactNode } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Activity,
  Droplets,
  Gauge,
  LayoutGrid,
  LogOut,
  Map as MapIcon,
  Ruler,
  ShieldCheck,
  Users,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useStore } from "@/lib/store"

function NavLink({
  href,
  active,
  icon: Icon,
  children,
}: {
  href: string
  active: boolean
  icon: ComponentType<{ className?: string }>
  children: ReactNode
}) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
        active
          ? "bg-sidebar-primary text-sidebar-primary-foreground"
          : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
      )}
    >
      <Icon className="size-4 shrink-0" aria-hidden="true" />
      <span className="truncate">{children}</span>
    </Link>
  )
}

export function Sidebar() {
  const pathname = usePathname()
  const { zones, totalZones, totalAreaSqFt, session, logout } = useStore()

  return (
    <aside className="flex w-full shrink-0 flex-col gap-5 bg-sidebar p-4 text-sidebar-foreground md:h-screen md:w-72 md:overflow-y-auto">
      <Link href="/" className="flex items-center gap-3 px-2 py-1">
        <span className="flex size-10 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
          <Droplets className="size-6" aria-hidden="true" />
        </span>
        <span className="flex flex-col leading-tight">
          <span className="text-base font-bold tracking-wide">AQUA GUARDIAN</span>
          <span className="text-xs text-sidebar-foreground/60">Leakage &amp; Loss Detection</span>
        </span>
      </Link>

      <nav className="flex flex-col gap-1">
        <p className="px-3 pb-1 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/50">
          Access
        </p>
        <NavLink href="/admin" active={pathname === "/admin"} icon={ShieldCheck}>
          Admin Area
        </NavLink>
        <NavLink href="/workers" active={pathname === "/workers"} icon={Users}>
          Workers Area
        </NavLink>
      </nav>

      <div className="flex flex-col gap-2">
        <p className="px-3 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/50">
          Overview
        </p>
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-lg bg-sidebar-accent p-3">
            <div className="flex items-center gap-1.5 text-sidebar-foreground/60">
              <LayoutGrid className="size-3.5" aria-hidden="true" />
              <span className="text-[11px] font-medium">Total Zones</span>
            </div>
            <p className="mt-1 text-2xl font-bold text-sidebar-primary">{totalZones}</p>
          </div>
          <div className="rounded-lg bg-sidebar-accent p-3">
            <div className="flex items-center gap-1.5 text-sidebar-foreground/60">
              <Ruler className="size-3.5" aria-hidden="true" />
              <span className="text-[11px] font-medium">Pipe Area</span>
            </div>
            <p className="mt-1 text-lg font-bold text-sidebar-primary">
              {totalAreaSqFt.toLocaleString()}
              <span className="ml-1 text-[10px] font-normal text-sidebar-foreground/50">sq ft</span>
            </p>
          </div>
        </div>
      </div>

      <nav className="flex flex-col gap-1">
        <p className="px-3 pb-1 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/50">
          Zones
        </p>
        {zones.map((zone) => (
          <NavLink
            key={zone.id}
            href={`/zones/${zone.id}`}
            active={pathname === `/zones/${zone.id}`}
            icon={MapIcon}
          >
            {zone.name}
          </NavLink>
        ))}
        <NavLink
          href="/pipeline-status"
          active={pathname === "/pipeline-status"}
          icon={Activity}
        >
          Pipe Line Status
        </NavLink>
      </nav>

      <div className="mt-auto flex flex-col gap-2 border-t border-sidebar-border pt-4">
        {session ? (
          <div className="flex items-center justify-between gap-2 rounded-md bg-sidebar-accent px-3 py-2">
            <div className="flex min-w-0 items-center gap-2">
              <Gauge className="size-4 shrink-0 text-sidebar-primary" aria-hidden="true" />
              <div className="min-w-0 leading-tight">
                <p className="truncate text-sm font-medium">{session.username}</p>
                <p className="text-[11px] capitalize text-sidebar-foreground/60">{session.role}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={logout}
              className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-sidebar-foreground/70 hover:bg-sidebar-primary hover:text-sidebar-primary-foreground"
            >
              <LogOut className="size-3.5" aria-hidden="true" />
              Exit
            </button>
          </div>
        ) : (
          <p className="px-3 text-xs text-sidebar-foreground/50">Not signed in</p>
        )}
      </div>
    </aside>
  )
}
