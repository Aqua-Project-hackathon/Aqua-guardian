// Built-in fallback knowledge base for the Aqua Guardian assistant.
// Used when the AI Gateway is unavailable so the chatbot always responds.

type Entry = {
  keywords: string[]
  answer: string
}

const ENTRIES: Entry[] = [
  {
    keywords: ["color", "colour", "health", "level", "red", "amber", "green", "legend", "mean"],
    answer:
      "Pipe health is shown in three levels:\n\n• Red (\"bad\") — the pipe or junction is damaged and likely leaking. Prioritize these for inspection.\n• Amber (\"good\") — aging infrastructure that's still working but worth watching.\n• Green (\"better\") — healthy, no action needed.\n\nYou'll see these colors on each zone map and summarized on the Pipe Line Status page.",
  },
  {
    keywords: ["map", "zone", "read", "branch", "root", "network", "junction", "navigate"],
    answer:
      "Each zone map draws the pipeline as a root-like branching network. Thicker lines are main trunks; thinner ones are branches feeding smaller areas. Junction dots are connection points where segments meet. The color of every segment and junction reflects its health (red/amber/green). Open a zone from the sidebar to inspect it, or use Pipe Line Status for an all-zones overview.",
  },
  {
    keywords: ["heavy", "damage", "leak", "burst", "emergency", "repair", "dispatch", "crew"],
    answer:
      "When a pipe takes HEAVY damage, Aqua Guardian raises a red alert banner and sounds a buzzer so admins and workers notice immediately. What to do:\n\n1. Note the zone and segment shown in the alert.\n2. Open that zone's map to confirm the affected branch.\n3. Dispatch a repair crew to isolate and fix the segment.\n4. The alert clears once the segment is no longer reporting heavy damage.",
  },
  {
    keywords: ["alert", "buzzer", "banner", "notification", "alarm", "sound"],
    answer:
      "The alert system watches every zone for heavy pipe damage. If it detects a critical leak, it shows a red banner across the app and plays a buzzer to grab attention. Both admins and workers see alerts so a repair crew can be dispatched quickly.",
  },
  {
    keywords: ["admin", "worker", "add", "role", "permission", "manage", "user", "access"],
    answer:
      "Admins have full control: they can add other admins, add workers, and create new zones (specifying the pipeline area in sq ft) from the Admin Dashboard. Workers have read-only access — they can view zone maps and the Pipe Line Status page but can't change anything.",
  },
  {
    keywords: ["login", "log in", "sign in", "password", "lock", "locked", "attempt", "security"],
    answer:
      "Logins are protected per role. After 3 failed attempts, that role is locked out for 5 minutes before you can try again. Make sure you're using the correct role (admin vs worker) and credentials.",
  },
  {
    keywords: ["status", "pipeline status", "overview", "aggregate", "summary", "dashboard"],
    answer:
      "The Pipe Line Status page aggregates health across every zone so you can see the overall condition of the network at a glance — how many segments are healthy, aging, or damaged — without opening each zone individually.",
  },
  {
    keywords: ["leakage", "loss", "detection", "what is", "about", "aqua guardian", "purpose", "help"],
    answer:
      "Aqua Guardian is a water-pipeline leakage and loss detection system. It splits a municipal network into zones, maps each zone's pipes as a branching network, and continuously reports the health of every segment. When it detects heavy damage it alerts your team so leaks are found and fixed before water (and money) is lost. Ask me about pipe colors, reading the maps, alerts, or managing zones and users.",
  },
]

const GREETING =
  "Hi! I'm the Aqua Guardian assistant. I can help you understand pipe health colors, read the zone maps, handle leak alerts, and manage zones, admins, and workers. What would you like to know?"

const FALLBACK =
  "I can help with Aqua Guardian's pipeline monitoring — things like what the pipe health colors mean, how to read a zone map, what to do when a heavy-damage alert fires, or how admins add zones and workers. Could you rephrase your question around one of those?"

export function answerLocally(question: string): string {
  const q = (question || "").toLowerCase().trim()

  if (!q) return GREETING
  if (/^(hi|hey|hello|yo|hiya|good (morning|afternoon|evening))\b/.test(q)) return GREETING

  let best: { entry: Entry; score: number } | null = null
  for (const entry of ENTRIES) {
    const score = entry.keywords.reduce((acc, kw) => (q.includes(kw) ? acc + 1 : acc), 0)
    if (score > 0 && (!best || score > best.score)) best = { entry, score }
  }

  return best ? best.entry.answer : FALLBACK
}
