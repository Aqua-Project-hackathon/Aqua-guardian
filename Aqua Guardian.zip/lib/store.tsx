"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react"
import { generateNetwork, type PipeNetwork } from "./pipeline"

export interface Account {
  username: string
  password: string
}

export interface Zone {
  id: string
  name: string
  areaSqFt: number
  seed: number
  forceHeavy?: boolean
}

export type Role = "admin" | "worker"

export interface Session {
  role: Role
  username: string
}

interface LockInfo {
  attempts: number
  lockedUntil: number
}

export interface LoginResult {
  ok: boolean
  error?: string
  attemptsLeft?: number
  lockedUntil?: number
}

interface PersistShape {
  admins: Account[]
  workers: Account[]
  zones: Zone[]
  session: Session | null
  locks: Record<Role, LockInfo>
}

export const MAX_ATTEMPTS = 3
export const LOCK_MS = 5 * 60 * 1000

const STORAGE_KEY = "aqua-guardian-state-v1"

const DEFAULT_STATE: PersistShape = {
  admins: [{ username: "admin", password: "admin123" }],
  workers: [{ username: "worker", password: "worker123" }],
  zones: [
    { id: "a", name: "Zone A", areaSqFt: 12500, seed: 11 },
    { id: "b", name: "Zone B", areaSqFt: 9800, seed: 27, forceHeavy: true },
    { id: "c", name: "Zone C", areaSqFt: 15200, seed: 43 },
  ],
  session: null,
  locks: {
    admin: { attempts: 0, lockedUntil: 0 },
    worker: { attempts: 0, lockedUntil: 0 },
  },
}

interface StoreContextValue {
  hydrated: boolean
  admins: Account[]
  workers: Account[]
  zones: Zone[]
  session: Session | null
  locks: Record<Role, LockInfo>
  totalZones: number
  totalAreaSqFt: number
  login: (role: Role, username: string, password: string) => LoginResult
  logout: () => void
  addAdmin: (username: string, password: string) => { ok: boolean; error?: string }
  addWorker: (username: string, password: string) => { ok: boolean; error?: string }
  addZone: (name: string, areaSqFt: number) => { ok: boolean; error?: string }
  getNetwork: (zone: Zone) => PipeNetwork
  getHeavyDamage: () => { zone: Zone; nodeId: string }[]
}

const StoreContext = createContext<StoreContextValue | null>(null)

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistShape>(DEFAULT_STATE)
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw) as PersistShape
        setState({ ...DEFAULT_STATE, ...parsed })
      }
    } catch {
      // ignore corrupt storage
    }
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (!hydrated) return
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    } catch {
      // ignore quota errors
    }
  }, [state, hydrated])

  const login = useCallback<StoreContextValue["login"]>((role, username, password) => {
    const now = Date.now()
    let result: LoginResult = { ok: false }
    setState((prev) => {
      const lock = prev.locks[role]
      if (lock.lockedUntil > now) {
        result = { ok: false, error: "locked", lockedUntil: lock.lockedUntil }
        return prev
      }
      const list = role === "admin" ? prev.admins : prev.workers
      const match = list.find(
        (a) => a.username === username.trim() && a.password === password,
      )
      if (match) {
        result = { ok: true }
        return {
          ...prev,
          session: { role, username: match.username },
          locks: { ...prev.locks, [role]: { attempts: 0, lockedUntil: 0 } },
        }
      }
      const attempts = lock.attempts + 1
      if (attempts >= MAX_ATTEMPTS) {
        const lockedUntil = now + LOCK_MS
        result = { ok: false, error: "locked", attemptsLeft: 0, lockedUntil }
        return {
          ...prev,
          locks: { ...prev.locks, [role]: { attempts, lockedUntil } },
        }
      }
      result = { ok: false, error: "invalid", attemptsLeft: MAX_ATTEMPTS - attempts }
      return {
        ...prev,
        locks: { ...prev.locks, [role]: { attempts, lockedUntil: 0 } },
      }
    })
    return result
  }, [])

  const logout = useCallback(() => {
    setState((prev) => ({ ...prev, session: null }))
  }, [])

  const addAdmin = useCallback<StoreContextValue["addAdmin"]>((username, password) => {
    const u = username.trim()
    if (!u || !password) return { ok: false, error: "Username and password are required." }
    let error: string | undefined
    setState((prev) => {
      if (prev.admins.some((a) => a.username === u)) {
        error = "An admin with that username already exists."
        return prev
      }
      return { ...prev, admins: [...prev.admins, { username: u, password }] }
    })
    return { ok: !error, error }
  }, [])

  const addWorker = useCallback<StoreContextValue["addWorker"]>((username, password) => {
    const u = username.trim()
    if (!u || !password) return { ok: false, error: "Username and password are required." }
    let error: string | undefined
    setState((prev) => {
      if (prev.workers.some((a) => a.username === u)) {
        error = "A worker with that username already exists."
        return prev
      }
      return { ...prev, workers: [...prev.workers, { username: u, password }] }
    })
    return { ok: !error, error }
  }, [])

  const addZone = useCallback<StoreContextValue["addZone"]>((name, areaSqFt) => {
    const n = name.trim()
    if (!n) return { ok: false, error: "Zone name is required." }
    if (!Number.isFinite(areaSqFt) || areaSqFt <= 0)
      return { ok: false, error: "Pipeline area must be a positive number." }
    let error: string | undefined
    setState((prev) => {
      if (prev.zones.some((z) => z.name.toLowerCase() === n.toLowerCase())) {
        error = "A zone with that name already exists."
        return prev
      }
      const id = `z${Date.now().toString(36)}`
      const seed = Math.floor(Math.random() * 100000)
      return { ...prev, zones: [...prev.zones, { id, name: n, areaSqFt, seed }] }
    })
    return { ok: !error, error }
  }, [])

  const networks = useMemo(() => {
    const map: Record<string, PipeNetwork> = {}
    for (const zone of state.zones) {
      map[zone.id] = generateNetwork(zone.seed, { forceHeavy: zone.forceHeavy })
    }
    return map
  }, [state.zones])

  const getNetwork = useCallback<StoreContextValue["getNetwork"]>(
    (zone) => networks[zone.id] ?? generateNetwork(zone.seed, { forceHeavy: zone.forceHeavy }),
    [networks],
  )

  const getHeavyDamage = useCallback<StoreContextValue["getHeavyDamage"]>(() => {
    const out: { zone: Zone; nodeId: string }[] = []
    for (const zone of state.zones) {
      const net = networks[zone.id]
      if (!net) continue
      for (const node of net.nodes) {
        if (node.heavy) out.push({ zone, nodeId: node.id })
      }
    }
    return out
  }, [state.zones, networks])

  const value = useMemo<StoreContextValue>(
    () => ({
      hydrated,
      admins: state.admins,
      workers: state.workers,
      zones: state.zones,
      session: state.session,
      locks: state.locks,
      totalZones: state.zones.length,
      totalAreaSqFt: state.zones.reduce((sum, z) => sum + z.areaSqFt, 0),
      login,
      logout,
      addAdmin,
      addWorker,
      addZone,
      getNetwork,
      getHeavyDamage,
    }),
    [hydrated, state, login, logout, addAdmin, addWorker, addZone, getNetwork, getHeavyDamage],
  )

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useStore() {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error("useStore must be used within StoreProvider")
  return ctx
}
