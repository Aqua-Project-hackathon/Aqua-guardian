export type Health = "bad" | "good" | "better"

export interface PipeNode {
  id: string
  x: number
  y: number
  depth: number
  status: Health
  heavy?: boolean
}

export interface PipeEdge {
  id: string
  from: string
  to: string
  status: Health
  width: number
}

export interface PipeNetwork {
  nodes: PipeNode[]
  edges: PipeEdge[]
}

export const MAP_WIDTH = 800
export const MAP_HEIGHT = 540

export const HEALTH_COLORS: Record<Health, string> = {
  bad: "#ef4444",
  good: "#f59e0b",
  better: "#10b981",
}

export const HEALTH_LABELS: Record<Health, string> = {
  bad: "Bad",
  good: "Good",
  better: "Better",
}

function mulberry32(seed: number) {
  let a = seed >>> 0
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export function generateNetwork(seed: number, opts: { forceHeavy?: boolean } = {}): PipeNetwork {
  const rand = mulberry32(seed + 101)
  const nodes: PipeNode[] = []
  const edges: PipeEdge[] = []
  let counter = 0

  function pickStatus(): Health {
    const r = rand()
    if (r < 0.16) return "bad"
    if (r < 0.46) return "good"
    return "better"
  }

  function addNode(x: number, y: number, depth: number, status: Health): PipeNode {
    const node: PipeNode = { id: `n${counter++}`, x, y, depth, status }
    nodes.push(node)
    return node
  }

  const root = addNode(MAP_WIDTH / 2, 44, 0, "better")

  function branch(parent: PipeNode, angle: number, length: number, depth: number, width: number) {
    if (depth >= 5) return
    const childCount = depth === 0 ? 3 : rand() < 0.35 ? 1 : rand() < 0.82 ? 2 : 3
    const spread = depth === 0 ? 1.5 : 1.0
    for (let i = 0; i < childCount; i++) {
      const t = childCount === 1 ? 0 : i / (childCount - 1) - 0.5
      const a = angle + t * spread + (rand() - 0.5) * 0.35
      const len = length * (0.8 + rand() * 0.4)
      let cx = parent.x + Math.sin(a) * len
      const cy = parent.y + Math.abs(Math.cos(a)) * len * 0.7 + len * 0.35
      cx = Math.max(38, Math.min(MAP_WIDTH - 38, cx))
      const status = pickStatus()
      const child = addNode(cx, Math.min(MAP_HEIGHT - 26, cy), depth + 1, status)
      edges.push({
        id: `e-${parent.id}-${child.id}`,
        from: parent.id,
        to: child.id,
        status,
        width: Math.max(3, width),
      })
      branch(child, a, len * 0.72, depth + 1, width * 0.72)
    }
  }

  branch(root, 0, 150, 0, 16)

  const bads = nodes.filter((n) => n.status === "bad" && n.depth > 1)
  if (opts.forceHeavy) {
    const target = bads[0] ?? nodes[nodes.length - 1]
    target.status = "bad"
    target.heavy = true
  } else if (bads.length && rand() < 0.22) {
    bads[0].heavy = true
  }

  return { nodes, edges }
}

export function summarize(net: PipeNetwork) {
  let bad = 0
  let good = 0
  let better = 0
  let heavy = 0
  for (const n of net.nodes) {
    if (n.status === "bad") bad++
    else if (n.status === "good") good++
    else better++
    if (n.heavy) heavy++
  }
  const total = net.nodes.length
  const overall: Health = bad / total > 0.2 ? "bad" : good / total > 0.35 ? "good" : "better"
  return { bad, good, better, heavy, total, overall }
}
