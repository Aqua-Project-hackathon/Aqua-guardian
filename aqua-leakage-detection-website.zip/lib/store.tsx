"use client"

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from "react"

export type PipeStatus = "bad" | "good" | "better"

export type Pipeline = {
  id: string
  name: string
  status: PipeStatus
}

export type Zone = {
  id: string
  name: string
  slug: string
  areaSqFt: number
  pipelines: Pipeline[]
}

export type Credential = {
  username: string
  password: string
}

export type Role = "admin" | "worker"

export type Session = {
  role: Role
  username: string
} | null

type Lockout = {
  attempts: number
  lockedUntil: number // epoch ms, 0 if not locked
}

type LockoutMap = {
  admin: Lockout
  worker: Lockout
}

type AquaState = {
  admins: Credential[]
  workers: Credential[]
  zones: Zone[]
  session: Session
  lockouts: LockoutMap
}

const MAX_ATTEMPTS = 3
const LOCK_MS = 4.5 * 60 * 1000 // ~4-5 minutes
const STORAGE_KEY = "aqua-guardian-state-v1"

const DEFAULT_STATE: AquaState = {
  admins: [{ username: "admin", password: "admin123" }],
  workers: [{ username: "worker", password: "worker123" }],
  zones: [
    {
      id: "zone-a",
      name: "Zone A",
      slug: "a",
      areaSqFt: 4200,
      pipelines: [
        { id: "a1", name: "Main Trunk A", status: "good" },
        { id: "a2", name: "North Branch A", status: "better" },
        { id: "a3", name: "East Branch A", status: "bad" },
      ],
    },
    {
      id: "zone-b",
      name: "Zone B",
      slug: "b",
      areaSqFt: 3100,
      pipelines: [
        { id: "b1", name: "Main Trunk B", status: "better" },
        { id: "b2", name: "West Branch B", status: "good" },
      ],
    },
    {
      id: "zone-c",
      name: "Zone C",
      slug: "c",
      areaSqFt: 5600,
      pipelines: [
        { id: "c1", name: "Main Trunk C", status: "good" },
        { id: "c2", name: "South Branch C", status: "bad" },
        { id: "c3", name: "Loop Line C", status: "good" },
      ],
    },
  ],
  session: null,
  lockouts: {
    admin: { attempts: 0, lockedUntil: 0 },
    worker: { attempts: 0, lockedUntil: 0 },
  },
}

type LoginResult =
  | { ok: true }
  | { ok: false; reason: "locked"; lockedUntil: number }
  | { ok: false; reason: "invalid"; attemptsLeft: number }

type AquaContextValue = {
  ready: boolean
  admins: Credential[]
  workers: Credential[]
  zones: Zone[]
  session: Session
  lockouts: LockoutMap
  totalZones: number
  totalAreaSqFt: number
  login: (role: Role, username: string, password: string) => LoginResult
  logout: () => void
  addAdmin: (username: string, password: string) => { ok: boolean; error?: string }
  addWorker: (username: string, password: string) => { ok: boolean; error?: string }
  addZone: (input: {
    name: string
    areaSqFt: number
    pipelines: { name: string; status: PipeStatus }[]
  }) => { ok: boolean; error?: string }
  setPipelineStatus: (zoneId: string, pipelineId: string, status: PipeStatus) => void
}

const AquaContext = createContext<AquaContextValue | null>(null)

function slugify(name: string) {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
}

export function AquaProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AquaState>(DEFAULT_STATE)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw) as AquaState
        setState({ ...DEFAULT_STATE, ...parsed })
      }
    } catch {
      // ignore corrupt storage, fall back to defaults
    }
    setReady(true)
  }, [])

  useEffect(() => {
    if (!ready) return
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    } catch {
      // storage may be unavailable; app still works in-memory
    }
  }, [state, ready])

  const login = useCallback<AquaContextValue["login"]>((role, username, password) => {
    let result: LoginResult = { ok: false, reason: "invalid", attemptsLeft: MAX_ATTEMPTS }
    setState((prev) => {
      const now = Date.now()
      const lock = prev.lockouts[role]

      if (lock.lockedUntil > now) {
        result = { ok: false, reason: "locked", lockedUntil: lock.lockedUntil }
        return prev
      }

      const list = role === "admin" ? prev.admins : prev.workers
      const match = list.find(
        (c) => c.username === username.trim() && c.password === password,
      )

      if (match) {
        result = { ok: true }
        return {
          ...prev,
          session: { role, username: match.username },
          lockouts: { ...prev.lockouts, [role]: { attempts: 0, lockedUntil: 0 } },
        }
      }

      const attempts = lock.attempts + 1
      if (attempts >= MAX_ATTEMPTS) {
        const lockedUntil = now + LOCK_MS
        result = { ok: false, reason: "locked", lockedUntil }
        return {
          ...prev,
          lockouts: { ...prev.lockouts, [role]: { attempts: 0, lockedUntil } },
        }
      }

      result = { ok: false, reason: "invalid", attemptsLeft: MAX_ATTEMPTS - attempts }
      return {
        ...prev,
        lockouts: { ...prev.lockouts, [role]: { attempts, lockedUntil: 0 } },
      }
    })
    return result
  }, [])

  const logout = useCallback(() => {
    setState((prev) => ({ ...prev, session: null }))
  }, [])

  const addAdmin = useCallback<AquaContextValue["addAdmin"]>((username, password) => {
    const u = username.trim()
    if (!u || !password) return { ok: false, error: "Username and password are required." }
    let error: string | undefined
    setState((prev) => {
      if (prev.admins.some((a) => a.username === u)) {
        error = "An admin with that username already exists."
        return prev
      }
      return { ...prev, admins: [...prev.admins, { username: u, password }] }
    })
    return error ? { ok: false, error } : { ok: true }
  }, [])

  const addWorker = useCallback<AquaContextValue["addWorker"]>((username, password) => {
    const u = username.trim()
    if (!u || !password) return { ok: false, error: "Username and password are required." }
    let error: string | undefined
    setState((prev) => {
      if (prev.workers.some((w) => w.username === u)) {
        error = "A worker with that username already exists."
        return prev
      }
      return { ...prev, workers: [...prev.workers, { username: u, password }] }
    })
    return error ? { ok: false, error } : { ok: true }
  }, [])

  const addZone = useCallback<AquaContextValue["addZone"]>((input) => {
    const name = input.name.trim()
    if (!name) return { ok: false, error: "Zone name is required." }
    if (!Number.isFinite(input.areaSqFt) || input.areaSqFt <= 0) {
      return { ok: false, error: "Pipe line area must be a positive number." }
    }
    let error: string | undefined
    setState((prev) => {
      const slug = slugify(name)
      if (prev.zones.some((z) => z.slug === slug || z.name === name)) {
        error = "A zone with that name already exists."
        return prev
      }
      const id = `zone-${slug || Date.now()}`
      const pipelines: Pipeline[] = input.pipelines
        .filter((p) => p.name.trim())
        .map((p, i) => ({
          id: `${id}-p${i}`,
          name: p.name.trim(),
          status: p.status,
        }))
      const newZone: Zone = { id, name, slug, areaSqFt: input.areaSqFt, pipelines }
      return { ...prev, zones: [...prev.zones, newZone] }
    })
    return error ? { ok: false, error } : { ok: true }
  }, [])

  const setPipelineStatus = useCallback<AquaContextValue["setPipelineStatus"]>(
    (zoneId, pipelineId, status) => {
      setState((prev) => ({
        ...prev,
        zones: prev.zones.map((z) =>
          z.id !== zoneId
            ? z
            : {
                ...z,
                pipelines: z.pipelines.map((p) =>
                  p.id === pipelineId ? { ...p, status } : p,
                ),
              },
        ),
      }))
    },
    [],
  )

  const totalAreaSqFt = state.zones.reduce((sum, z) => sum + z.areaSqFt, 0)

  const value: AquaContextValue = {
    ready,
    admins: state.admins,
    workers: state.workers,
    zones: state.zones,
    session: state.session,
    lockouts: state.lockouts,
    totalZones: state.zones.length,
    totalAreaSqFt,
    login,
    logout,
    addAdmin,
    addWorker,
    addZone,
    setPipelineStatus,
  }

  return <AquaContext.Provider value={value}>{children}</AquaContext.Provider>
}

export function useAqua() {
  const ctx = useContext(AquaContext)
  if (!ctx) throw new Error("useAqua must be used within AquaProvider")
  return ctx
}

export const LOCKOUT_CONFIG = { MAX_ATTEMPTS, LOCK_MS }
