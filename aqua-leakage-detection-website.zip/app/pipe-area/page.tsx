"use client"

import Link from "next/link"
import { Ruler, Lock, Map } from "lucide-react"
import { useAqua } from "@/lib/store"
import { PageHeader } from "@/components/app-shell"
import { PipelineMap } from "@/components/pipeline-map"

export default function PipeAreaPage() {
  const { zones, totalAreaSqFt, session } = useAqua()
  const max = Math.max(...zones.map((z) => z.areaSqFt), 1)

  return (
    <div className="min-h-full">
      <PageHeader
        title="Total Pipe Line Area"
        description="The combined pipe line coverage across all zones, in square feet. Admins set the area when adding a zone; workers can view it."
      />

      <div className="p-8">
        <div className="mb-8 flex flex-col items-center justify-center rounded-3xl border border-border bg-card py-12">
          <span className="mb-4 flex size-16 items-center justify-center rounded-2xl bg-primary/15">
            <Ruler className="size-8 text-primary" />
          </span>
          <p className="text-6xl font-black text-primary">
            {totalAreaSqFt.toLocaleString()}
          </p>
          <p className="mt-2 text-sm text-muted-foreground">Square feet of pipe line</p>

          {(!session || session.role !== "admin") && (
            <p className="mt-4 flex items-center gap-1.5 text-xs text-muted-foreground">
              <Lock className="size-3.5" /> Only admins can change pipe line area
            </p>
          )}
        </div>

        <div className="mb-8 rounded-2xl border border-border bg-card p-6">
          <div className="mb-5 flex items-center gap-2">
            <Map className="size-5 text-primary" />
            <h3 className="text-base font-bold">All Zones Map</h3>
            <span className="ml-auto text-xs text-muted-foreground">
              {zones.length} {zones.length === 1 ? "zone" : "zones"} ·{" "}
              {Math.max(zones.length, 1)} {zones.length === 1 ? "tank" : "tanks"}
            </span>
          </div>

          {/* Combined network fed by one tank per zone */}
          <div className="mb-6 overflow-hidden rounded-xl border border-border bg-secondary/30">
            <div className="aspect-[16/7] w-full">
              <PipelineMap
                seed="all-zones-combined"
                sources={Math.max(zones.length, 1)}
                className="h-full w-full"
              />
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3">
              <span className="text-sm font-semibold">
                Combined Pipe Line Network
              </span>
              <span className="text-xs text-muted-foreground">
                {Math.max(zones.length, 1)} tank
                {zones.length === 1 ? "" : "s"} supplying{" "}
                {totalAreaSqFt.toLocaleString()} ft²
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {zones.map((z) => {
              const tanks = Math.max(1, Math.ceil(z.pipelines.length / 2))
              return (
                <Link
                  key={z.id}
                  href={`/zone/${z.slug}`}
                  className="group overflow-hidden rounded-xl border border-border bg-secondary/30 transition-colors hover:border-primary"
                >
                  <div className="aspect-[16/10] w-full">
                    <PipelineMap seed={z.slug} sources={tanks} className="h-full w-full" />
                  </div>
                  <div className="flex items-center justify-between px-4 py-3">
                    <span className="text-sm font-semibold group-hover:text-primary">
                      {z.name}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {tanks} tank{tanks === 1 ? "" : "s"} ·{" "}
                      {z.areaSqFt.toLocaleString()} ft²
                    </span>
                  </div>
                </Link>
              )
            })}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-6">
          <h3 className="mb-5 text-base font-bold">Area by Zone</h3>
          <div className="flex flex-col gap-4">
            {zones.map((z) => (
              <div key={z.id}>
                <div className="mb-1.5 flex items-center justify-between text-sm">
                  <Link href={`/zone/${z.slug}`} className="font-medium hover:text-primary">
                    {z.name}
                  </Link>
                  <span className="text-muted-foreground">
                    {z.areaSqFt.toLocaleString()} ft²
                  </span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-secondary">
                  <div
                    className="h-full rounded-full bg-primary"
                    style={{ width: `${(z.areaSqFt / max) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
