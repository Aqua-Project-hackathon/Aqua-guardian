"use client"

import Link from "next/link"
import { Droplets, Shield, HardHat, Activity } from "lucide-react"
import { useAqua } from "@/lib/store"

export default function HomePage() {
  const { totalZones, totalAreaSqFt } = useAqua()

  return (
    <div className="relative flex min-h-full flex-col items-center justify-center overflow-hidden px-6 py-16 text-center">
      {/* ambient background */}
      <div
        className="pointer-events-none absolute inset-0 -z-10 opacity-60"
        style={{
          background:
            "radial-gradient(60% 50% at 50% 35%, rgba(63,201,238,0.18), transparent 70%)",
        }}
        aria-hidden
      />

      <span className="mb-6 flex size-20 items-center justify-center rounded-3xl bg-primary/15 ring-1 ring-primary/30">
        <Droplets className="size-10 text-primary" />
      </span>

      <h1 className="text-5xl font-black tracking-tight sm:text-6xl md:text-7xl">
        AQUA GUARDIAN
      </h1>
      <p className="mt-4 max-w-xl text-pretty text-base text-muted-foreground sm:text-lg">
        Real-time water pipeline monitoring — detecting leakage and loss across every
        zone of your distribution network.
      </p>

      <div className="mt-10 grid w-full max-w-2xl grid-cols-2 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-border bg-card/60 px-5 py-4">
          <p className="text-3xl font-bold text-primary">{totalZones}</p>
          <p className="mt-1 text-xs text-muted-foreground">Total Zones</p>
        </div>
        <div className="rounded-2xl border border-border bg-card/60 px-5 py-4">
          <p className="text-3xl font-bold text-primary">
            {totalAreaSqFt.toLocaleString()}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">Pipe Line Area (ft²)</p>
        </div>
        <div className="col-span-2 rounded-2xl border border-border bg-card/60 px-5 py-4 sm:col-span-1">
          <p className="text-3xl font-bold text-primary">24/7</p>
          <p className="mt-1 text-xs text-muted-foreground">Live Monitoring</p>
        </div>
      </div>

      <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
        <Link
          href="/admin"
          className="flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
        >
          <Shield className="size-4" />
          Admin Area
        </Link>
        <Link
          href="/workers"
          className="flex items-center gap-2 rounded-lg border border-border bg-card px-5 py-2.5 text-sm font-semibold transition-colors hover:bg-accent"
        >
          <HardHat className="size-4" />
          Workers Area
        </Link>
        <Link
          href="/pipe-status"
          className="flex items-center gap-2 rounded-lg border border-border bg-card px-5 py-2.5 text-sm font-semibold transition-colors hover:bg-accent"
        >
          <Activity className="size-4" />
          Pipe Line Status
        </Link>
      </div>
    </div>
  )
}
