"use client"

import Link from "next/link"
import { Layers, MapPin, ArrowRight, Lock } from "lucide-react"
import { useAqua } from "@/lib/store"
import { PageHeader } from "@/components/app-shell"

export default function ZonesPage() {
  const { zones, totalZones, session } = useAqua()

  return (
    <div className="min-h-full">
      <PageHeader
        title="Total Number of Zones"
        description="A live count of monitored zones. Only admins can add zones; workers and visitors can view the count."
      />

      <div className="p-8">
        <div className="mb-8 flex flex-col items-center justify-center rounded-3xl border border-border bg-card py-12">
          <span className="mb-4 flex size-16 items-center justify-center rounded-2xl bg-primary/15">
            <Layers className="size-8 text-primary" />
          </span>
          <p className="text-6xl font-black text-primary">{totalZones}</p>
          <p className="mt-2 text-sm text-muted-foreground">Zones currently monitored</p>

          {(!session || session.role !== "admin") && (
            <p className="mt-4 flex items-center gap-1.5 text-xs text-muted-foreground">
              <Lock className="size-3.5" /> Adding zones requires admin access
            </p>
          )}
          {session?.role === "admin" && (
            <Link
              href="/admin"
              className="mt-4 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90"
            >
              Add a new zone
            </Link>
          )}
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {zones.map((z) => (
            <Link
              key={z.id}
              href={`/zone/${z.slug}`}
              className="group flex items-center justify-between rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/50"
            >
              <div className="flex items-center gap-3">
                <MapPin className="size-5 text-primary" />
                <div>
                  <p className="font-semibold">{z.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {z.areaSqFt.toLocaleString()} ft² • {z.pipelines.length} pipe lines
                  </p>
                </div>
              </div>
              <ArrowRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-1" />
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
