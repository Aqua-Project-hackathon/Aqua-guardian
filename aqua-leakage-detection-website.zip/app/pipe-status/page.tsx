"use client"

import { useState } from "react"
import { Activity, ShieldCheck, ShieldAlert, ShieldHalf, Droplet } from "lucide-react"
import { useAqua, type PipeStatus, type Zone } from "@/lib/store"
import { PageHeader } from "@/components/app-shell"
import { PipelineMap } from "@/components/pipeline-map"

const STATUS_META: Record<
  PipeStatus,
  { label: string; color: string; chip: string; icon: React.ComponentType<{ className?: string }>; desc: string }
> = {
  better: {
    label: "Better",
    color: "text-sky-400",
    chip: "bg-sky-500/15 text-sky-400 ring-sky-500/30",
    icon: ShieldCheck,
    desc: "Optimal condition — no loss detected.",
  },
  good: {
    label: "Good",
    color: "text-emerald-400",
    chip: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/30",
    icon: ShieldHalf,
    desc: "Healthy — operating within normal range.",
  },
  bad: {
    label: "Bad",
    color: "text-destructive",
    chip: "bg-destructive/15 text-destructive ring-destructive/30",
    icon: ShieldAlert,
    desc: "Damaged — leakage or loss detected. Needs repair.",
  },
}

export default function PipeStatusPage() {
  const { zones } = useAqua()
  const [activeSlug, setActiveSlug] = useState(zones[0]?.slug ?? "")
  const active = zones.find((z) => z.slug === activeSlug) ?? zones[0]

  const allPipes = zones.flatMap((z) => z.pipelines)
  const counts = {
    better: allPipes.filter((p) => p.status === "better").length,
    good: allPipes.filter((p) => p.status === "good").length,
    bad: allPipes.filter((p) => p.status === "bad").length,
  }

  return (
    <div className="min-h-full">
      <PageHeader
        title="Pipe Line Status"
        description="Health of the pipe line network. Damaged pipes flagged as bad show a leak marker on the map; good and better pipes are running normally."
      />

      <div className="p-8">
        {/* summary */}
        <div className="mb-6 grid gap-4 sm:grid-cols-3">
          {(["better", "good", "bad"] as PipeStatus[]).map((s) => {
            const meta = STATUS_META[s]
            const Icon = meta.icon
            return (
              <div key={s} className="rounded-2xl border border-border bg-card p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className={`size-5 ${meta.color}`} />
                    <span className="font-semibold">{meta.label}</span>
                  </div>
                  <span className={`text-2xl font-black ${meta.color}`}>{counts[s]}</span>
                </div>
                <p className="mt-2 text-xs text-muted-foreground">{meta.desc}</p>
              </div>
            )
          })}
        </div>

        {/* zone switcher */}
        <div className="mb-4 flex flex-wrap gap-2">
          {zones.map((z) => (
            <button
              key={z.id}
              onClick={() => setActiveSlug(z.slug)}
              className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                z.slug === active?.slug
                  ? "bg-primary text-primary-foreground"
                  : "border border-border bg-card text-muted-foreground hover:bg-accent"
              }`}
            >
              {z.name}
            </button>
          ))}
        </div>

        {active && <ZoneStatusView zone={active} />}
      </div>
    </div>
  )
}

function ZoneStatusView({ zone }: { zone: Zone }) {
  const { session, setPipelineStatus } = useAqua()
  const isAdmin = session?.role === "admin"

  return (
    <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <div className="flex items-center gap-2 border-b border-border px-5 py-3">
          <Activity className="size-4 text-primary" />
          <span className="text-sm font-semibold">{zone.name} — Health Map</span>
        </div>
        <PipelineMap
          seed={`zone-${zone.slug}`}
          mode="status"
          sources={Math.min(4, Math.max(2, Math.ceil(zone.pipelines.length / 2)))}
          className="aspect-[16/10] w-full"
        />
        <div className="flex flex-wrap gap-4 border-t border-border px-5 py-3 text-xs">
          <Legend color="#3fc9ee" label="Better" />
          <Legend color="#38d39f" label="Good" />
          <Legend color="#f0525a" label="Bad (leak detected)" />
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="mb-4 text-sm font-bold uppercase tracking-wide">
          Pipe Line Health
        </h3>
        <ul className="flex flex-col gap-3">
          {zone.pipelines.map((p) => {
            const meta = STATUS_META[p.status]
            const Icon = meta.icon
            return (
              <li
                key={p.id}
                className="rounded-xl border border-border/60 bg-background p-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className={`size-4 ${meta.color}`} />
                    <span className="text-sm font-medium">{p.name}</span>
                  </div>
                  <span
                    className={`rounded-md px-2 py-0.5 text-xs font-semibold ring-1 ${meta.chip}`}
                  >
                    {meta.label}
                  </span>
                </div>
                {p.status === "bad" && (
                  <p className="mt-2 flex items-center gap-1.5 text-xs text-destructive">
                    <Droplet className="size-3.5" /> Damaged pipe — leakage detected,
                    repair required.
                  </p>
                )}
                {isAdmin && (
                  <div className="mt-3 flex items-center gap-1.5">
                    <span className="text-[11px] text-muted-foreground">Set status:</span>
                    {(["better", "good", "bad"] as PipeStatus[]).map((s) => (
                      <button
                        key={s}
                        onClick={() => setPipelineStatus(zone.id, p.id, s)}
                        className={`rounded-md px-2 py-0.5 text-[11px] font-medium transition-colors ${
                          p.status === s
                            ? "bg-primary text-primary-foreground"
                            : "border border-border text-muted-foreground hover:bg-accent"
                        }`}
                      >
                        {STATUS_META[s].label}
                      </button>
                    ))}
                  </div>
                )}
              </li>
            )
          })}
          {zone.pipelines.length === 0 && (
            <li className="text-sm text-muted-foreground">
              No pipe lines recorded for this zone.
            </li>
          )}
        </ul>
        {!isAdmin && (
          <p className="mt-4 text-xs text-muted-foreground">
            Sign in as an admin to update pipe line status.
          </p>
        )}
      </div>
    </div>
  )
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5 text-muted-foreground">
      <span className="size-3 rounded-full" style={{ backgroundColor: color }} />
      {label}
    </span>
  )
}
