"use client"

import { use } from "react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { Ruler, GitBranch, ArrowLeft } from "lucide-react"
import { useAqua, type PipeStatus } from "@/lib/store"
import { PageHeader } from "@/components/app-shell"
import { PipelineMap } from "@/components/pipeline-map"

const STATUS_STYLES: Record<PipeStatus, string> = {
  bad: "bg-destructive/15 text-destructive",
  good: "bg-emerald-500/15 text-emerald-400",
  better: "bg-sky-500/15 text-sky-400",
}

const STATUS_LABEL: Record<PipeStatus, string> = {
  bad: "Bad",
  good: "Good",
  better: "Better",
}

export default function ZoneDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = use(params)
  const { zones } = useAqua()
  const zone = zones.find((z) => z.slug === slug)

  if (!zone) return notFound()

  return (
    <div className="min-h-full">
      <PageHeader
        title={`${zone.name} — Pipeline Map`}
        description="Branching pipe line network for this zone, laid out like a root system across the map."
        action={
          <Link
            href="/zones"
            className="flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium transition-colors hover:bg-accent"
          >
            <ArrowLeft className="size-4" /> All Zones
          </Link>
        }
      />

      <div className="grid gap-6 p-8 lg:grid-cols-[1.6fr_1fr]">
        <div className="overflow-hidden rounded-2xl border border-border bg-card">
          <PipelineMap
            seed={`zone-${zone.slug}`}
            sources={Math.min(4, Math.max(2, Math.ceil(zone.pipelines.length / 2)))}
            className="aspect-[16/10] w-full"
          />
        </div>

        <div className="flex flex-col gap-6">
          <div className="rounded-2xl border border-border bg-card p-6">
            <div className="mb-2 flex items-center gap-2 text-muted-foreground">
              <Ruler className="size-4" />
              <span className="text-xs font-medium uppercase tracking-wide">
                Pipe Line Area
              </span>
            </div>
            <p className="text-4xl font-black text-primary">
              {zone.areaSqFt.toLocaleString()}
              <span className="ml-1 text-lg font-semibold text-muted-foreground">
                ft²
              </span>
            </p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6">
            <div className="mb-4 flex items-center gap-2">
              <GitBranch className="size-4 text-primary" />
              <h3 className="text-sm font-bold uppercase tracking-wide">
                Pipe Lines ({zone.pipelines.length})
              </h3>
            </div>
            <ul className="flex flex-col gap-2">
              {zone.pipelines.map((p) => (
                <li
                  key={p.id}
                  className="flex items-center justify-between rounded-lg border border-border/60 bg-background px-3 py-2 text-sm"
                >
                  <span>{p.name}</span>
                  <span
                    className={`rounded-md px-2 py-0.5 text-xs font-semibold ${STATUS_STYLES[p.status]}`}
                  >
                    {STATUS_LABEL[p.status]}
                  </span>
                </li>
              ))}
              {zone.pipelines.length === 0 && (
                <li className="text-sm text-muted-foreground">
                  No pipe lines recorded for this zone yet.
                </li>
              )}
            </ul>
          </div>

          <Link
            href="/pipe-status"
            className="rounded-2xl border border-border bg-card p-4 text-center text-sm font-medium text-primary transition-colors hover:bg-accent"
          >
            View full pipe line status →
          </Link>
        </div>
      </div>
    </div>
  )
}
