"use client"

import { useState } from "react"
import { UserPlus, HardHat, Layers, Plus, Trash2, ShieldCheck, X } from "lucide-react"
import { useAqua, type PipeStatus } from "@/lib/store"
import { LoginForm } from "@/components/login-form"
import { PageHeader } from "@/components/app-shell"

export default function AdminPage() {
  const { session } = useAqua()

  if (!session || session.role !== "admin") {
    return (
      <div className="min-h-full">
        <PageHeader
          title="Admin Area"
          description="Sign in with administrator credentials. Three failed attempts will lock this area for several minutes."
        />
        <LoginForm
          role="admin"
          title="Administrator Sign In"
          hint="Demo login — admin / admin123"
        />
      </div>
    )
  }

  return <AdminDashboard />
}

type Banner = { type: "ok" | "error"; text: string } | null

function AdminDashboard() {
  const { admins, workers, zones, addAdmin, addWorker } = useAqua()
  const [showAddAdmin, setShowAddAdmin] = useState(false)

  return (
    <div className="min-h-full">
      <PageHeader
        title="Admin Control Center"
        description="Manage administrators, workers, and the pipeline network. Only admins can add workers, zones, and pipe line area."
        action={
          <button
            onClick={() => setShowAddAdmin(true)}
            className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          >
            <UserPlus className="size-4" />
            Add Admin
          </button>
        }
      />

      <div className="grid gap-6 p-8 lg:grid-cols-2">
        <StatCard label="Administrators" value={admins.length} icon={ShieldCheck} />
        <StatCard label="Workers" value={workers.length} icon={HardHat} />

        <AddWorkerCard />
        <AddZoneCard />

        <div className="lg:col-span-2">
          <ZoneList />
        </div>
      </div>

      {showAddAdmin && <AddAdminModal onClose={() => setShowAddAdmin(false)} onAdd={addAdmin} />}
    </div>
  )
}

function StatCard({
  label,
  value,
  icon: Icon,
}: {
  label: string
  value: number
  icon: React.ComponentType<{ className?: string }>
}) {
  return (
    <div className="flex items-center gap-4 rounded-2xl border border-border bg-card p-5">
      <span className="flex size-12 items-center justify-center rounded-xl bg-primary/15">
        <Icon className="size-6 text-primary" />
      </span>
      <div>
        <p className="text-2xl font-bold">{value}</p>
        <p className="text-sm text-muted-foreground">{label}</p>
      </div>
    </div>
  )
}

function AddAdminModal({
  onClose,
  onAdd,
}: {
  onClose: () => void
  onAdd: (u: string, p: string) => { ok: boolean; error?: string }
}) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [banner, setBanner] = useState<Banner>(null)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const res = onAdd(username, password)
    if (res.ok) {
      setBanner({ type: "ok", text: `Admin "${username}" added.` })
      setUsername("")
      setPassword("")
    } else {
      setBanner({ type: "error", text: res.error ?? "Could not add admin." })
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-2xl border border-border bg-card p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-bold">Add New Admin</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="size-4" />
          </button>
        </div>
        <form onSubmit={submit} className="flex flex-col gap-3">
          <Field label="Username" value={username} onChange={setUsername} />
          <Field label="Password" type="password" value={password} onChange={setPassword} />
          {banner && (
            <p
              className={
                banner.type === "ok"
                  ? "text-xs text-primary"
                  : "text-xs text-destructive"
              }
            >
              {banner.text}
            </p>
          )}
          <button className="mt-1 h-10 rounded-lg bg-primary text-sm font-semibold text-primary-foreground hover:opacity-90">
            Create Admin
          </button>
        </form>
      </div>
    </div>
  )
}

function AddWorkerCard() {
  const { addWorker } = useAqua()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [banner, setBanner] = useState<Banner>(null)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const res = addWorker(username, password)
    if (res.ok) {
      setBanner({ type: "ok", text: `Worker "${username}" added.` })
      setUsername("")
      setPassword("")
    } else {
      setBanner({ type: "error", text: res.error ?? "Could not add worker." })
    }
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="mb-4 flex items-center gap-2">
        <HardHat className="size-5 text-primary" />
        <h3 className="text-base font-bold">Add Worker</h3>
      </div>
      <p className="mb-4 text-xs text-muted-foreground">
        Worker credentials are created by admins. Workers can view zones and pipe line
        status but cannot make changes.
      </p>
      <form onSubmit={submit} className="flex flex-col gap-3">
        <Field label="Worker Username" value={username} onChange={setUsername} />
        <Field label="Worker Password" type="password" value={password} onChange={setPassword} />
        {banner && (
          <p className={banner.type === "ok" ? "text-xs text-primary" : "text-xs text-destructive"}>
            {banner.text}
          </p>
        )}
        <button className="mt-1 flex h-10 items-center justify-center gap-2 rounded-lg bg-primary text-sm font-semibold text-primary-foreground hover:opacity-90">
          <UserPlus className="size-4" /> Add Worker
        </button>
      </form>
    </div>
  )
}

type DraftPipe = { name: string; status: PipeStatus }

function AddZoneCard() {
  const { addZone } = useAqua()
  const [name, setName] = useState("")
  const [area, setArea] = useState("")
  const [pipes, setPipes] = useState<DraftPipe[]>([{ name: "", status: "good" }])
  const [banner, setBanner] = useState<Banner>(null)

  function updatePipe(i: number, patch: Partial<DraftPipe>) {
    setPipes((prev) => prev.map((p, idx) => (idx === i ? { ...p, ...patch } : p)))
  }

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const res = addZone({
      name,
      areaSqFt: Number(area),
      pipelines: pipes,
    })
    if (res.ok) {
      setBanner({ type: "ok", text: `Zone "${name}" added with ${area} ft² of pipe line.` })
      setName("")
      setArea("")
      setPipes([{ name: "", status: "good" }])
    } else {
      setBanner({ type: "error", text: res.error ?? "Could not add zone." })
    }
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="mb-4 flex items-center gap-2">
        <Layers className="size-5 text-primary" />
        <h3 className="text-base font-bold">Add Zone & Pipe Line</h3>
      </div>
      <p className="mb-4 text-xs text-muted-foreground">
        Adding a zone increases the total zone count. You must specify how many square
        feet of pipe line the zone adds.
      </p>
      <form onSubmit={submit} className="flex flex-col gap-3">
        <Field label="Zone Name" value={name} onChange={setName} placeholder="e.g. Zone D" />
        <Field
          label="Pipe Line Area (ft²)"
          value={area}
          onChange={setArea}
          type="number"
          placeholder="e.g. 3800"
        />

        <div className="flex flex-col gap-2">
          <span className="text-xs font-medium text-muted-foreground">Pipe Lines</span>
          {pipes.map((p, i) => (
            <div key={i} className="flex items-center gap-2">
              <input
                value={p.name}
                onChange={(e) => updatePipe(i, { name: e.target.value })}
                placeholder={`Pipe line ${i + 1} name`}
                className="h-9 flex-1 rounded-lg border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
              />
              <select
                value={p.status}
                onChange={(e) => updatePipe(i, { status: e.target.value as PipeStatus })}
                className="h-9 rounded-lg border border-input bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="better">Better</option>
                <option value="good">Good</option>
                <option value="bad">Bad</option>
              </select>
              {pipes.length > 1 && (
                <button
                  type="button"
                  onClick={() => setPipes((prev) => prev.filter((_, idx) => idx !== i))}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="size-4" />
                </button>
              )}
            </div>
          ))}
          <button
            type="button"
            onClick={() => setPipes((prev) => [...prev, { name: "", status: "good" }])}
            className="flex items-center gap-1 self-start text-xs text-primary hover:underline"
          >
            <Plus className="size-3.5" /> Add another pipe line
          </button>
        </div>

        {banner && (
          <p className={banner.type === "ok" ? "text-xs text-primary" : "text-xs text-destructive"}>
            {banner.text}
          </p>
        )}
        <button className="mt-1 flex h-10 items-center justify-center gap-2 rounded-lg bg-primary text-sm font-semibold text-primary-foreground hover:opacity-90">
          <Plus className="size-4" /> Create Zone
        </button>
      </form>
    </div>
  )
}

function ZoneList() {
  const { zones } = useAqua()
  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <h3 className="mb-4 text-base font-bold">Existing Zones</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-xs text-muted-foreground">
              <th className="pb-2 font-medium">Zone</th>
              <th className="pb-2 font-medium">Pipe Line Area</th>
              <th className="pb-2 font-medium">Pipe Lines</th>
            </tr>
          </thead>
          <tbody>
            {zones.map((z) => (
              <tr key={z.id} className="border-b border-border/50 last:border-0">
                <td className="py-3 font-medium">{z.name}</td>
                <td className="py-3 text-muted-foreground">
                  {z.areaSqFt.toLocaleString()} ft²
                </td>
                <td className="py-3 text-muted-foreground">{z.pipelines.length}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  type?: string
  placeholder?: string
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="h-10 rounded-lg border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
        required
      />
    </label>
  )
}
