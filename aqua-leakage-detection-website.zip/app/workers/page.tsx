"use client"

import Link from "next/link"
import { Layers, Ruler, MapPin, Activity, Eye } from "lucide-react"
import { useAqua } from "@/lib/store"
import { LoginForm } from "@/components/login-form"
import { PageHeader } from "@/components/app-shell"

export default function WorkersPage() {
  const { session } = useAqua()

  if (!session) {
    return (
      <div className="min-h-full">
        <PageHeader
          title="Workers Area"
          description="Sign in with worker credentials provided by an administrator. Three failed attempts will lock this area for several minutes."
        />
        <LoginForm
          role="worker"
          title="Worker Sign In"
          hint="Demo login — worker / worker123 (or ask an admin to add you)"
        />
      </div>
    )
  }

  return <WorkerDashboard />
}

function WorkerDashboard() {
  const { zones, totalZones, totalAreaSqFt } = useAqua()

  return (
    <div className="min-h-full">
      <PageHeader
        title="Workers Dashboard"
        description="View-only access to zones, pipe line counts, and network status. Changes are made by administrators."
      />

      <div className="grid gap-6 p-8">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="flex items-center gap-4 rounded-2xl border border-border bg-card p-5">
            <span className="flex size-12 items-center justify-center rounded-xl bg-primary/15">
              <Layers className="size-6 text-primary" />
            </span>
            <div>
              <p className="text-2xl font-bold">{totalZones}</p>
              <p className="text-sm text-muted-foreground">Total Number of Zones</p>
            </div>
          </div>
          <div className="flex items-center gap-4 rounded-2xl border border-border bg-card p-5">
            <span className="flex size-12 items-center justify-center rounded-xl bg-primary/15">
              <Ruler className="size-6 text-primary" />
            </span>
            <div>
              <p className="text-2xl font-bold">{totalAreaSqFt.toLocaleString()} ft²</p>
              <p className="text-sm text-muted-foreground">Total Pipe Line Area</p>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-6">
          <div className="mb-4 flex items-center gap-2">
            <Eye className="size-5 text-primary" />
            <h3 className="text-base font-bold">Zones (view only)</h3>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {zones.map((z) => (
              <Link
                key={z.id}
                href={`/zone/${z.slug}`}
                className="group rounded-xl border border-border bg-background p-4 transition-colors hover:border-primary/50"
              >
                <div className="mb-2 flex items-center gap-2">
                  <MapPin className="size-4 text-primary" />
                  <span className="font-semibold">{z.name}</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {z.areaSqFt.toLocaleString()} ft² • {z.pipelines.length} pipe lines
                </p>
              </Link>
            ))}
          </div>
          <Link
            href="/pipe-status"
            className="mt-5 inline-flex items-center gap-2 text-sm text-primary hover:underline"
          >
            <Activity className="size-4" /> View pipe line status
          </Link>
        </div>
      </div>
    </div>
  )
}
