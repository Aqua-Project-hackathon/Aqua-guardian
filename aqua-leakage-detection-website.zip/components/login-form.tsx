"use client"

import { useEffect, useState } from "react"
import { Lock, User, TriangleAlert, ShieldCheck } from "lucide-react"
import { useAqua, type Role } from "@/lib/store"

function formatCountdown(ms: number) {
  const total = Math.max(0, Math.ceil(ms / 1000))
  const m = Math.floor(total / 60)
  const s = total % 60
  return `${m}:${s.toString().padStart(2, "0")}`
}

export function LoginForm({
  role,
  title,
  hint,
}: {
  role: Role
  title: string
  hint?: string
}) {
  const { login, lockouts } = useAqua()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [message, setMessage] = useState<{ type: "error" | "info"; text: string } | null>(
    null,
  )
  const [now, setNow] = useState(() => Date.now())

  const lockedUntil = lockouts[role].lockedUntil
  const isLocked = lockedUntil > now
  const attemptsUsed = lockouts[role].attempts

  useEffect(() => {
    if (!isLocked) return
    const t = setInterval(() => setNow(Date.now()), 500)
    return () => clearInterval(t)
  }, [isLocked])

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const result = login(role, username, password)
    if (result.ok) {
      setMessage(null)
      setPassword("")
      return
    }
    if (result.reason === "locked") {
      setMessage({
        type: "error",
        text: "Too many failed attempts. This area is temporarily locked.",
      })
      setNow(Date.now())
    } else {
      setMessage({
        type: "error",
        text: `Invalid username or password. ${result.attemptsLeft} attempt${
          result.attemptsLeft === 1 ? "" : "s"
        } remaining before lockout.`,
      })
    }
    setPassword("")
  }

  return (
    <div className="flex min-h-full items-center justify-center px-6 py-12">
      <div className="w-full max-w-sm rounded-2xl border border-border bg-card p-7 shadow-xl">
        <div className="mb-6 flex flex-col items-center text-center">
          <span className="mb-3 flex size-12 items-center justify-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
            <ShieldCheck className="size-6 text-primary" />
          </span>
          <h2 className="text-lg font-bold">{title}</h2>
          {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
        </div>

        {isLocked ? (
          <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-5 text-center">
            <TriangleAlert className="mx-auto mb-2 size-6 text-destructive" />
            <p className="text-sm font-semibold text-foreground">Access Locked</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Retry available in
            </p>
            <p className="mt-1 font-mono text-2xl font-bold text-destructive">
              {formatCountdown(lockedUntil - now)}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <label className="flex flex-col gap-1.5">
              <span className="text-xs font-medium text-muted-foreground">Username</span>
              <div className="flex items-center gap-2 rounded-lg border border-input bg-background px-3 focus-within:ring-2 focus-within:ring-ring">
                <User className="size-4 text-muted-foreground" />
                <input
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="h-10 w-full bg-transparent text-sm outline-none"
                  placeholder="Enter username"
                  required
                />
              </div>
            </label>

            <label className="flex flex-col gap-1.5">
              <span className="text-xs font-medium text-muted-foreground">Password</span>
              <div className="flex items-center gap-2 rounded-lg border border-input bg-background px-3 focus-within:ring-2 focus-within:ring-ring">
                <Lock className="size-4 text-muted-foreground" />
                <input
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-10 w-full bg-transparent text-sm outline-none"
                  placeholder="Enter password"
                  required
                />
              </div>
            </label>

            {message && (
              <p
                className={
                  message.type === "error"
                    ? "flex items-start gap-1.5 text-xs text-destructive"
                    : "text-xs text-muted-foreground"
                }
              >
                {message.type === "error" && (
                  <TriangleAlert className="mt-0.5 size-3.5 shrink-0" />
                )}
                <span>{message.text}</span>
              </p>
            )}

            {!message && attemptsUsed > 0 && (
              <p className="text-xs text-muted-foreground">
                {3 - attemptsUsed} attempt(s) remaining.
              </p>
            )}

            <button
              type="submit"
              className="mt-1 h-10 rounded-lg bg-primary text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
            >
              Sign In
            </button>
          </form>
        )}
      </div>
    </div>
  )
}
