"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Shield,
  HardHat,
  Layers,
  Ruler,
  MapPin,
  Activity,
  Droplets,
  LogOut,
} from "lucide-react"
import { useAqua } from "@/lib/store"
import { cn } from "@/lib/utils"

type NavItem = {
  href: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  value?: string
}

export function Sidebar() {
  const pathname = usePathname()
  const { zones, totalZones, totalAreaSqFt, session, logout } = useAqua()

  const nav: { section: string; items: NavItem[] }[] = [
    {
      section: "Access",
      items: [
        { href: "/admin", label: "Admin Area", icon: Shield },
        { href: "/workers", label: "Workers Area", icon: HardHat },
      ],
    },
    {
      section: "Network Overview",
      items: [
        {
          href: "/zones",
          label: "Total Number of Zones",
          icon: Layers,
          value: String(totalZones),
        },
        {
          href: "/pipe-area",
          label: "Total Pipe Line Area",
          icon: Ruler,
          value: `${totalAreaSqFt.toLocaleString()} ft²`,
        },
      ],
    },
    {
      section: "Zones",
      items: zones.map((z) => ({
        href: `/zone/${z.slug}`,
        label: z.name,
        icon: MapPin,
      })),
    },
    {
      section: "Monitoring",
      items: [{ href: "/pipe-status", label: "Pipe Line Status", icon: Activity }],
    },
  ]

  return (
    <aside className="flex h-full w-72 shrink-0 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
      <Link href="/" className="flex items-center gap-3 px-5 py-5">
        <span className="flex size-10 items-center justify-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
          <Droplets className="size-5 text-primary" />
        </span>
        <span className="flex flex-col leading-tight">
          <span className="text-sm font-bold tracking-wide">AQUA GUARDIAN</span>
          <span className="text-[11px] text-muted-foreground">
            Leakage & Loss Detection
          </span>
        </span>
      </Link>

      <nav className="flex-1 overflow-y-auto px-3 pb-4">
        {nav.map((group) => (
          <div key={group.section} className="mb-5">
            <p className="px-2 pb-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
              {group.section}
            </p>
            <ul className="flex flex-col gap-1">
              {group.items.map((item) => {
                const active =
                  pathname === item.href ||
                  (item.href !== "/" && pathname.startsWith(item.href))
                const Icon = item.icon
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className={cn(
                        "group flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                        active
                          ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                          : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                      )}
                    >
                      <Icon className="size-4 shrink-0" />
                      <span className="flex-1 truncate">{item.label}</span>
                      {item.value && (
                        <span className="rounded-md bg-primary/15 px-1.5 py-0.5 text-[11px] font-semibold text-primary">
                          {item.value}
                        </span>
                      )}
                    </Link>
                  </li>
                )
              })}
            </ul>
          </div>
        ))}
      </nav>

      <div className="border-t border-sidebar-border p-3">
        {session ? (
          <div className="flex items-center justify-between gap-2 rounded-lg bg-sidebar-accent/50 px-3 py-2">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{session.username}</p>
              <p className="text-[11px] capitalize text-muted-foreground">
                {session.role} session
              </p>
            </div>
            <button
              onClick={logout}
              className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-muted-foreground transition-colors hover:bg-destructive/20 hover:text-foreground"
            >
              <LogOut className="size-3.5" />
              Logout
            </button>
          </div>
        ) : (
          <p className="px-2 text-[11px] text-muted-foreground">
            Not signed in. Access Admin or Workers area to continue.
          </p>
        )}
      </div>
    </aside>
  )
}
