"use client"

import { useMemo } from "react"
import type { PipeStatus } from "@/lib/store"

type Segment = {
  x1: number
  y1: number
  x2: number
  y2: number
  depth: number
  status: PipeStatus
}

type Source = { x: number; y: number }

// Deterministic PRNG so a given seed always draws the same network.
function mulberry32(seed: number) {
  return function () {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function seedFromString(s: string) {
  let h = 2166136261
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

const WIDTH = 820
const HEIGHT = 520

const STATUS_COLOR: Record<PipeStatus, string> = {
  bad: "#f0525a",
  good: "#38d39f",
  better: "#3fc9ee",
}

function buildNetwork(
  seed: string,
  statusMode: boolean,
  sourceCount: number,
): { segments: Segment[]; sources: Source[] } {
  const rand = mulberry32(seedFromString(seed))
  const segments: Segment[] = []

  const pickStatus = (): PipeStatus => {
    if (!statusMode) return "good"
    const r = rand()
    if (r < 0.18) return "bad"
    if (r < 0.55) return "good"
    return "better"
  }

  function grow(
    x: number,
    y: number,
    angle: number,
    length: number,
    depth: number,
  ) {
    if (depth <= 0 || length < 20) return
    const x2 = x + Math.cos(angle) * length
    const y2 = y + Math.sin(angle) * length
    segments.push({ x1: x, y1: y, x2, y2, depth, status: pickStatus() })

    // More branches + one extra depth level => a denser mesh of nodes.
    const branches = 2 + Math.floor(rand() * 3)
    for (let i = 0; i < branches; i++) {
      const spread = (rand() - 0.5) * 1.2
      grow(x2, y2, angle + spread, length * (0.6 + rand() * 0.18), depth - 1)
    }
  }

  // Each tank source feeds its own root-system of pipes. When several tanks
  // exist they are stacked down the left edge and cover the whole area.
  const sources: Source[] = []
  const count = Math.max(1, sourceCount)
  for (let i = 0; i < count; i++) {
    const sy = HEIGHT * ((i + 1) / (count + 1))
    const sx = 52
    sources.push({ x: sx, y: sy })
    const trunkLen = count > 1 ? 130 : 150
    grow(sx + 20, sy, -0.1 + rand() * 0.2, trunkLen, 6)
    grow(sx + 20, sy, 0.5 + rand() * 0.2, trunkLen * 0.82, 5)
    grow(sx + 20, sy, -0.6 - rand() * 0.2, trunkLen * 0.82, 5)
  }
  return { segments, sources }
}

function Tank({ x, y }: Source) {
  // A small water tank / reservoir glyph used as a supply source.
  return (
    <g aria-hidden="true">
      <ellipse cx={x} cy={y + 15} rx="15" ry="5" fill="#05101a" opacity="0.5" />
      <rect
        x={x - 14}
        y={y - 15}
        width="28"
        height="30"
        rx="6"
        fill="#0d2436"
        stroke="#3fc9ee"
        strokeWidth="2"
      />
      <rect x={x - 14} y={y - 2} width="28" height="17" rx="4" fill="#3fc9ee" fillOpacity="0.55" />
      <ellipse cx={x} cy={y - 15} rx="14" ry="4.5" fill="#7fe0ff" />
      <circle cx={x} cy={y - 15} r="9" fill="none" stroke="#7fe0ff" strokeOpacity="0.5" strokeWidth="2">
        <animate attributeName="r" values="9;18;9" dur="2.4s" repeatCount="indefinite" />
        <animate attributeName="stroke-opacity" values="0.5;0;0.5" dur="2.4s" repeatCount="indefinite" />
      </circle>
    </g>
  )
}

export function PipelineMap({
  seed,
  mode = "plain",
  sources = 1,
  className,
}: {
  seed: string
  mode?: "plain" | "status"
  sources?: number
  className?: string
}) {
  const statusMode = mode === "status"
  const { segments, sources: tanks } = useMemo(
    () => buildNetwork(seed, statusMode, sources),
    [seed, statusMode, sources],
  )
  const leaks = statusMode ? segments.filter((s) => s.status === "bad") : []

  return (
    <div
      className={className}
      role="img"
      aria-label={
        statusMode
          ? "Pipeline health map showing pipe segments colored by condition with leak markers"
          : "Pipeline network map for the zone"
      }
    >
      <svg
        viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
        className="h-full w-full rounded-xl"
        preserveAspectRatio="xMidYMid slice"
      >
        {/* map base */}
        <rect width={WIDTH} height={HEIGHT} fill="#0d1b2a" />
        <rect width={WIDTH} height={HEIGHT} fill="url(#terrain)" />

        <defs>
          <radialGradient id="terrain" cx="35%" cy="45%" r="80%">
            <stop offset="0%" stopColor="#13324a" />
            <stop offset="100%" stopColor="#0a1622" />
          </radialGradient>
          <pattern id="grid" width="52" height="52" patternUnits="userSpaceOnUse">
            <path
              d="M 52 0 L 0 0 0 52"
              fill="none"
              stroke="#ffffff"
              strokeOpacity="0.05"
              strokeWidth="1"
            />
          </pattern>
        </defs>

        {/* street grid to feel like a real map */}
        <rect width={WIDTH} height={HEIGHT} fill="url(#grid)" />

        {/* a river / green belt accents */}
        <path
          d="M 0 90 C 200 130 320 40 520 110 S 780 160 820 120"
          fill="none"
          stroke="#1f5f7a"
          strokeOpacity="0.4"
          strokeWidth="26"
          strokeLinecap="round"
        />
        <path
          d="M 120 520 C 180 400 90 320 200 240"
          fill="none"
          stroke="#2f7a4a"
          strokeOpacity="0.18"
          strokeWidth="40"
          strokeLinecap="round"
        />

        {/* zone boundary */}
        <rect
          x="24"
          y="24"
          width={WIDTH - 48}
          height={HEIGHT - 48}
          rx="18"
          fill="none"
          stroke="#5fd0f0"
          strokeOpacity="0.5"
          strokeWidth="2"
          strokeDasharray="10 8"
        />

        {/* pipe casing (dark outline under each pipe) */}
        {segments.map((s, i) => (
          <line
            key={`case-${i}`}
            x1={s.x1}
            y1={s.y1}
            x2={s.x2}
            y2={s.y2}
            stroke="#05101a"
            strokeWidth={Math.max(3, s.depth * 2.2) + 4}
            strokeLinecap="round"
          />
        ))}

        {/* pipes */}
        {segments.map((s, i) => (
          <line
            key={`pipe-${i}`}
            x1={s.x1}
            y1={s.y1}
            x2={s.x2}
            y2={s.y2}
            stroke={statusMode ? STATUS_COLOR[s.status] : "#3fc9ee"}
            strokeWidth={Math.max(3, s.depth * 2.2)}
            strokeLinecap="round"
            strokeOpacity={0.95}
          />
        ))}

        {/* midpoint inline nodes (valves / sensors) for a denser network */}
        {segments.map((s, i) => {
          const mx = (s.x1 + s.x2) / 2
          const my = (s.y1 + s.y2) / 2
          return (
            <circle
              key={`mid-${i}`}
              cx={mx}
              cy={my}
              r={Math.max(1.6, s.depth * 0.6)}
              fill={statusMode ? STATUS_COLOR[s.status] : "#7fe0ff"}
              fillOpacity="0.85"
            />
          )
        })}

        {/* junction nodes */}
        {segments.map((s, i) => (
          <circle
            key={`node-${i}`}
            cx={s.x2}
            cy={s.y2}
            r={Math.max(2, s.depth * 0.9)}
            fill="#0d1b2a"
            stroke={statusMode ? STATUS_COLOR[s.status] : "#7fe0ff"}
            strokeWidth="1.5"
          />
        ))}

        {/* leak markers on damaged pipes */}
        {leaks.map((s, i) => {
          const mx = (s.x1 + s.x2) / 2
          const my = (s.y1 + s.y2) / 2
          return (
            <g key={`leak-${i}`}>
              <circle cx={mx} cy={my} r="14" fill="#f0525a" fillOpacity="0.25">
                <animate
                  attributeName="r"
                  values="8;18;8"
                  dur="1.6s"
                  repeatCount="indefinite"
                />
                <animate
                  attributeName="fill-opacity"
                  values="0.35;0.05;0.35"
                  dur="1.6s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle cx={mx} cy={my} r="4.5" fill="#f0525a" />
            </g>
          )
        })}

        {/* tank supply sources */}
        {tanks.map((t, i) => (
          <Tank key={`tank-${i}`} x={t.x} y={t.y} />
        ))}
      </svg>
    </div>
  )
}
